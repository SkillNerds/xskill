"""XSkill trajectory/Atom adapter for the standalone OpenEarth SDK."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Mapping, Optional, Union

from .analyst import Analyst
from .backend import OpenCodeBackend
from .config import load_config, role_config
from .contracts import (
    ExistingSkillInput,
    ScoredAtomInput,
    TrainingResult,
)
from .service import TrajectorySkillDistiller


_ORACLE_SCORE_FILE = "openearth-oracle-scores.json"


def _validate_score(value: object) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("ux_score must be an integer in 1..10")
    score = value
    if not 1 <= score <= 10:
        raise ValueError("ux_score must be an integer in 1..10")
    return score


def _oracle_score_path(workspace: Union[str, Path]) -> Path:
    return Path(workspace).expanduser().resolve() / _ORACLE_SCORE_FILE


def _load_oracle_scores(workspace: Union[str, Path]) -> dict:
    path = _oracle_score_path(workspace)
    if not path.is_file():
        return {"schema": 1, "trajectories": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if (
        not isinstance(value, dict)
        or value.get("schema") != 1
        or not isinstance(value.get("trajectories"), dict)
    ):
        raise ValueError(f"invalid OpenEarth oracle score store: {path}")
    return value


def record_oracle_score(
    *,
    workspace: Union[str, Path],
    trajectory_id: str,
    ux_score: int,
    case_id: str = "",
    metadata: Optional[Mapping[str, object]] = None,
) -> Path:
    """Persist a benchmark oracle score before creating a temp trajectory."""
    normalized_id = str(trajectory_id or "").strip()
    if not normalized_id:
        raise ValueError("trajectory_id must not be empty")
    score = _validate_score(ux_score)
    state = _load_oracle_scores(workspace)
    state["trajectories"][normalized_id] = {
        "ux_score": score,
        "case_id": str(case_id or ""),
        "metadata": dict(metadata or {}),
    }
    path = _oracle_score_path(workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(
        json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)
    return path


def _atom_inputs(
    trajectories,
    *,
    oracle_scores: Mapping[str, object],
) -> Iterable[ScoredAtomInput]:
    resources = (
        trajectories.iter() if hasattr(trajectories, "iter") else trajectories
    )
    score_rows = oracle_scores.get("trajectories", {})
    if not isinstance(score_rows, Mapping):
        score_rows = {}

    for trajectory in resources:
        if isinstance(trajectory, ScoredAtomInput):
            yield trajectory
            continue
        if getattr(trajectory, "atom_split_status", None) != "ready":
            continue

        atoms = tuple(getattr(trajectory, "atoms", ()) or ())
        source = str(getattr(trajectory, "source", "user") or "user")
        trajectory_id = str(
            getattr(trajectory, "trajectory_id", "") or ""
        )
        parent_id = str(getattr(trajectory, "id", "") or trajectory_id)
        if not trajectory_id or not parent_id:
            raise ValueError(
                "trajectory input must provide id and trajectory_id"
            )

        oracle_row = score_rows.get(trajectory_id)
        if source == "temp" and oracle_row is not None and len(atoms) != 1:
            raise ValueError(
                "an oracle-scored temp trajectory must produce exactly one "
                f"Atom; {trajectory_id!r} produced {len(atoms)}"
            )

        for atom in atoms:
            atom_id = str(getattr(atom, "atom_id", "") or "")
            if not atom_id:
                raise ValueError(
                    f"trajectory {trajectory_id!r} contains an Atom without atom_id"
                )
            metadata = {
                "parent_trajectory_id": parent_id,
                "trajectory_source": source,
                "offset_start": int(getattr(atom, "offset_start", 0) or 0),
                "offset_end": int(getattr(atom, "offset_end", 0) or 0),
            }
            if source == "temp":
                row = oracle_row if isinstance(oracle_row, Mapping) else {}
                score_value = row.get("ux_score")
                score = (
                    _validate_score(score_value)
                    if score_value is not None
                    else None
                )
                score_source = "oracle"
                metadata["benchmark_case_id"] = str(row.get("case_id") or "")
                extra = row.get("metadata")
                if isinstance(extra, Mapping):
                    metadata["oracle"] = dict(extra)
            else:
                score_value = getattr(atom, "ux_score", None)
                score = (
                    _validate_score(score_value)
                    if score_value is not None
                    else None
                )
                score_source = "xskill"

            yield ScoredAtomInput(
                atom_id=atom_id,
                evidence_id=f"{parent_id}#{atom_id}",
                parent_trajectory_id=parent_id,
                content=str(getattr(atom, "content", "") or ""),
                ux_score=score,
                intent=str(getattr(atom, "intent", "") or ""),
                summary=str(getattr(atom, "summary", "") or ""),
                used_skills=tuple(
                    getattr(atom, "used_skills", ()) or ()
                ),
                score_source=score_source,
                metadata=metadata,
            )


def _build_analyst(config: dict, workspace: Union[str, Path]) -> Analyst:
    settings = role_config(config, "reflect")
    model = str(settings.get("model") or "")
    base_url = str(settings.get("base_url") or "")
    if not model or not base_url:
        raise RuntimeError(
            "OpenEarth reflect agent is not configured; set reflect.model and "
            "reflect.base_url in the kernel config"
        )
    if base_url != "opencode":
        raise RuntimeError(
            "OpenEarth Skill SDK requires reflect.base_url=opencode; "
            "inject analyst=... to use another agent backend"
        )
    backend = OpenCodeBackend(
        model,
        binary=str(settings.get("binary") or "opencode"),
        timeout=float(settings.get("timeout") or 600),
    )
    return Analyst(backend, log_root=Path(workspace) / "logs")


def train_skills(
    *,
    config_path: Union[str, Path],
    workspace: Union[str, Path],
    trajectories,
    existing_skills: Iterable[ExistingSkillInput] = (),
    run_id: str,
    full_rebuild: bool = False,
    analyst=None,
    on_event=None,
) -> TrainingResult:
    """Train Skills from ready XSkill Atom views or normalized Atom inputs."""
    config = load_config(config_path)
    reflect_analyst = analyst or _build_analyst(config, workspace)
    settings = role_config(config, "reflect")
    service = TrajectorySkillDistiller(
        workspace=workspace,
        analyst=reflect_analyst,
        strategy_path=str(settings.get("strategy") or "") or None,
        on_event=on_event,
    )
    return service.distill(
        _atom_inputs(
            trajectories,
            oracle_scores=_load_oracle_scores(workspace),
        ),
        existing_skills,
        run_id=run_id,
        full_rebuild=full_rebuild,
    )
