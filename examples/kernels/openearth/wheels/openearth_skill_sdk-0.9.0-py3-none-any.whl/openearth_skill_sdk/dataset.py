"""Dataset loading and deterministic LiveMath train/test materialization."""
from __future__ import annotations

import glob
import hashlib
import json
import random
from pathlib import Path
from typing import Any, Optional, Union


_LABELS = list("ABCDEFG")


def _read_rows(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return []
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        value = None
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        nested = value.get("data")
        rows = nested if isinstance(nested, list) else list(value.values())
        return [row for row in rows if isinstance(row, dict)]
    return [
        json.loads(line)
        for line in text.splitlines()
        if line.strip()
    ]


def _label(value: object) -> str:
    return str(value or "").strip().upper().rstrip(".):")


def _choices(value: Any) -> list[dict]:
    if isinstance(value, dict):
        return [
            {"label": str(label).strip(), "text": str(text).strip()}
            for label, text in sorted(value.items())
            if str(text).strip()
        ]
    if not isinstance(value, list):
        return []
    result = []
    for index, item in enumerate(value[: len(_LABELS)]):
        if isinstance(item, dict):
            label = str(item.get("label") or _LABELS[index]).strip()
            text = str(item.get("text") or item.get("content") or "").strip()
        else:
            label = _LABELS[index]
            text = str(item).strip()
        if text:
            result.append({"label": label, "text": text})
    return result


def normalize_item(item: dict, row_index: int = 0, source_path: str = "") -> dict:
    mcq = item.get("mcq") if isinstance(item.get("mcq"), dict) else {}
    question = str(mcq.get("question") or item.get("question") or "").strip()
    choices = _choices(mcq.get("choices") or item.get("choices") or [])
    correct = mcq.get("correct_choice") or item.get("correct_choice") or {}
    if isinstance(correct, dict):
        correct_label = _label(correct.get("label"))
        correct_text = str(correct.get("text") or "").strip()
    else:
        correct_label = _label(correct)
        correct_text = ""
    by_label = {_label(choice["label"]): choice["text"] for choice in choices}
    if correct_label and not correct_text:
        correct_text = by_label.get(correct_label, "")
    month = str(item.get("month") or "").strip()
    number = item.get("no", row_index + 1)
    task_id = str(item.get("id") or (f"{month}:{number}" if month else number))
    return {
        **item,
        "id": task_id,
        "question": question,
        "choices": choices,
        "correct_choice": {
            "label": correct_label,
            "text": correct_text,
        },
        "theorem": str(item.get("theorem") or "").strip(),
        "sketch": str(item.get("sketch") or "").strip(),
        "source_path": source_path,
    }


def _valid(item: dict) -> bool:
    return bool(
        item.get("id")
        and item.get("question")
        and item.get("choices")
        and (item.get("correct_choice") or {}).get("label")
    )


def _load_materialized(root: Path) -> Optional[dict]:
    files = {
        split: root / split / "items.json"
        for split in ("train", "test")
    }
    if not all(path.is_file() for path in files.values()):
        return None
    return {
        split: [
            normalized
            for index, row in enumerate(_read_rows(path))
            if _valid(
                normalized := normalize_item(row, index, str(path))
            )
        ]
        for split, path in files.items()
    }


def load_items(path: Union[str, Path]) -> list[dict]:
    root = Path(path).expanduser()
    if not root.exists():
        raise FileNotFoundError(f"dataset does not exist: {root}")
    if root.is_file():
        files = [root]
    else:
        files = [
            Path(value)
            for value in sorted(
                set(
                    glob.glob(
                        str(root / "**" / "qa_*_final.json"),
                        recursive=True,
                    )
                )
            )
        ]
        if not files:
            files = sorted(root.glob("*.json")) + sorted(root.glob("*.jsonl"))
    result = []
    for file in files:
        for index, row in enumerate(_read_rows(file)):
            item = normalize_item(row, index, str(file))
            if _valid(item):
                result.append(item)
    if not result:
        raise ValueError(f"no valid LiveMath tasks found under {root}")
    return result


def build_splits(
    path: Union[str, Path],
    *,
    split_seed: int = 42,
    n_train: Optional[int] = None,
    n_test: Optional[int] = None,
) -> dict:
    root = Path(path).expanduser()
    materialized = _load_materialized(root) if root.is_dir() else None
    if materialized is not None:
        splits = materialized
    else:
        items = load_items(root)
        shuffled = list(items)
        random.Random(split_seed).shuffle(shuffled)
        train_count = (
            max(1, int(len(shuffled) * 0.2))
            if len(shuffled) > 1
            else len(shuffled)
        )
        splits = {
            "train": shuffled[:train_count],
            "test": shuffled[train_count:],
        }
    if n_train is not None:
        splits["train"] = splits["train"][:n_train]
    if n_test is not None:
        splits["test"] = splits["test"][:n_test]
    if not splits.get("train") or not splits.get("test"):
        raise ValueError("dataset requires non-empty train and test splits")
    train_ids = {str(item["id"]) for item in splits["train"]}
    test_ids = {str(item["id"]) for item in splits["test"]}
    overlap = sorted(train_ids & test_ids)
    if overlap:
        raise ValueError(
            "train and test task IDs overlap: " + ", ".join(overlap[:10])
        )
    return splits


def shuffle_choices(item: dict, seed: int) -> dict:
    choices = [dict(choice) for choice in item.get("choices", [])]
    digest = hashlib.sha256(
        f"{seed}:{item.get('id', '')}".encode("utf-8")
    ).hexdigest()
    random.Random(int(digest[:16], 16)).shuffle(choices)
    original = _label((item.get("correct_choice") or {}).get("label"))
    correct = dict(item.get("correct_choice") or {})
    remapped = []
    for index, choice in enumerate(choices[: len(_LABELS)]):
        new_label = _LABELS[index]
        if _label(choice.get("label")) == original:
            correct = {
                "label": new_label,
                "text": str(choice.get("text") or "").strip(),
            }
        remapped.append({
            "label": new_label,
            "text": str(choice.get("text") or "").strip(),
        })
    return {**item, "choices": remapped, "correct_choice": correct}


def dataset_identity(root: Union[str, Path]) -> tuple[str, list[dict]]:
    source = Path(root).expanduser().resolve()
    records = []
    for path in sorted(source.rglob("*")):
        if (
            not path.is_file()
            or path.is_symlink()
            or ".git" in path.parts
        ):
            continue
        digest = hashlib.sha256()
        size = 0
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
                size += len(block)
        records.append({
            "path": path.relative_to(source).as_posix(),
            "sha256": digest.hexdigest(),
            "bytes": size,
        })
    if not records:
        raise ValueError(f"dataset contains no regular files: {source}")
    payload = json.dumps(
        records,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest(), records
