"""Dataset-environment registry for the standalone Skill SDK."""
from __future__ import annotations

import re
import shutil
import tempfile
from pathlib import Path
from typing import Optional, Union

from .contracts import TargetRun
from .dataset import build_splits as build_livemath_splits
from .dataset import shuffle_choices
from .officeqa import OfficeQAEnvironment
from .spreadsheet import SpreadsheetEnvironment


def task_context(task: dict) -> str:
    question = str(
        task.get("question") or task.get("instruction") or ""
    )
    choices = "\n".join(
        f"{choice.get('label')}. {choice.get('text')}"
        for choice in task.get("choices", [])
    )
    details = []
    if task.get("answer_position"):
        details.append(f"checked_range={task.get('answer_position')}")
    if task.get("answer_sheet"):
        details.append(f"checked_sheet={task.get('answer_sheet')}")
    return "\n".join(
        part for part in (question, choices, " ".join(details)) if part
    )


def _choice_answer(text: str, labels: set[str]) -> str:
    for pattern in (
        r"(?:final\s+answer|answer|答案)\s*(?:is|是|[:：])?\s*[\[(]?\s*([A-G])",
        r"\b([A-G])\b",
    ):
        matches = re.findall(pattern, text or "", re.IGNORECASE)
        for value in reversed(matches):
            label = str(value).upper()
            if label in labels:
                return label
    return ""


class LiveMathEnvironment:
    name = "livemath"

    def __init__(
        self,
        root: Union[str, Path],
        run_config: dict,
        *,
        workspace: Optional[Union[str, Path]] = None,
    ):
        self.splits = build_livemath_splits(
            root,
            split_seed=int(run_config.get("split_seed") or 42),
            n_train=run_config.get("n_train"),
            n_test=run_config.get("n_test"),
        )
        if run_config.get("shuffle_choices", True) is not False:
            seed = int(run_config.get("choice_seed") or 42)
            self.splits = {
                split: [
                    shuffle_choices(task, seed)
                    for task in tasks
                ]
                for split, tasks in self.splits.items()
            }
        self.work_root = (
            Path(workspace).resolve() / "openearth-benchmark-runs"
            if workspace
            else None
        )
        if self.work_root is not None:
            self.work_root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def query(task: dict) -> str:
        return task_context(task)

    def prepare(self, task: dict) -> tuple[Path, str]:
        workdir = Path(tempfile.mkdtemp(
            prefix="oe-skill-livemath-",
            dir=self.work_root,
        ))
        choices = "\n".join(
            f"{choice.get('label')}. {choice.get('text')}"
            for choice in task.get("choices", [])
        )
        prompt = (
            "Solve this multiple-choice mathematics task. Use the installed "
            "Skills when relevant. Write only the final option label to "
            "answer.txt, then explain briefly in the final response.\n\n"
            f"Question:\n{task.get('question', '')}\n\n"
            f"Choices:\n{choices}\n"
        )
        return workdir, prompt

    @staticmethod
    def score(
        task: dict,
        workdir: Path,
        *,
        transcript: str,
        selected_skills: tuple[str, ...],
        cost: float,
        process_error: str,
    ) -> TargetRun:
        labels = {
            str(choice.get("label") or "").strip().upper()
            for choice in task.get("choices", [])
        }
        correct = str(
            (task.get("correct_choice") or {}).get("label") or ""
        ).strip().upper()
        answer_file = workdir / "answer.txt"
        answer_text = (
            answer_file.read_text(encoding="utf-8")
            if answer_file.is_file()
            else ""
        )
        answer = _choice_answer(answer_text, labels) or _choice_answer(
            transcript,
            labels,
        )
        hard = int(bool(answer) and answer == correct)
        error = process_error
        if not error and not answer:
            error = "no valid answer label produced"
        elif not error and not hard:
            error = f"predicted {answer!r} but expected {correct!r}"
        return TargetRun(
            task_id=str(task.get("id") or ""),
            answer=answer,
            correct_answer=correct,
            hard=hard,
            soft=float(hard),
            transcript=transcript,
            selected_skills=selected_skills,
            cost=cost,
            error=error,
        )

    @staticmethod
    def cleanup(workdir: Path) -> None:
        shutil.rmtree(workdir, ignore_errors=True)

    @staticmethod
    def manifest() -> dict:
        return {"oracle": "livemath-choice-label-em"}


def build_environment(
    name: str,
    dataset_root: Union[str, Path],
    run_config: dict,
    *,
    workspace: Optional[Union[str, Path]] = None,
):
    if name == "livemath":
        return LiveMathEnvironment(
            dataset_root,
            run_config,
            workspace=workspace,
        )
    if name == "spreadsheet":
        return SpreadsheetEnvironment(
            dataset_root,
            run_config,
            workspace=workspace,
        )
    if name == "officeqa":
        return OfficeQAEnvironment(
            dataset_root,
            run_config,
            workspace=workspace,
        )
    raise ValueError(
        "run.env must be one of: livemath, spreadsheet, officeqa"
    )
