"""Strict YAML frontmatter support for complete SKILL.md artifacts."""
from __future__ import annotations

import yaml


class FrontmatterError(ValueError):
    pass


def parse_strict(text: str) -> tuple[dict, str]:
    if not text or not text.startswith("---"):
        return {}, text or ""
    lines = text.split("\n")
    if lines[0].rstrip("\r").strip() != "---":
        return {}, text
    closing = next(
        (
            index
            for index in range(1, len(lines))
            if lines[index].rstrip("\r").strip() == "---"
        ),
        -1,
    )
    if closing == -1:
        raise FrontmatterError("missing closing '---' delimiter")
    try:
        frontmatter = yaml.safe_load("\n".join(lines[1:closing])) or {}
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        location = (
            f" at line {mark.line + 2}, column {mark.column + 1}" if mark else ""
        )
        problem = getattr(exc, "problem", None) or str(exc).splitlines()[0]
        raise FrontmatterError(f"{problem}{location}") from exc
    if not isinstance(frontmatter, dict):
        raise FrontmatterError("frontmatter must be a YAML mapping")
    body = lines[closing + 1 :]
    if body and not body[0].strip():
        body = body[1:]
    return frontmatter, "\n".join(body)


def serialize(frontmatter: dict, body: str) -> str:
    if not frontmatter:
        return body or ""
    yaml_text = yaml.safe_dump(
        frontmatter,
        sort_keys=False,
        allow_unicode=True,
        default_flow_style=False,
        width=100,
    ).rstrip("\n")
    body = body or ""
    separator = "" if body.startswith("\n") else "\n"
    return f"---\n{yaml_text}\n---\n{separator}{body}"
