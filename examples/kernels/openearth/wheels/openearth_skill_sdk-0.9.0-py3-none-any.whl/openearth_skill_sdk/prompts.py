"""Prompts for the standalone layered Skill distillation pipeline."""
from __future__ import annotations

from importlib.resources import files
from pathlib import Path
from typing import Optional


SKILL_LEVEL_CLASSIFICATION_INSTRUCTIONS = """\
Classify existing runtime Skills for OpenEarth's layered reflection.

Return JSON only: one array item for every requested Skill, in the same order:
{"name":"exact input name","level":"planning|functional|unclassified",
 "confidence":0.0,"reason":"short reason"}

Use planning for reusable multi-step strategy, ordering, branching, or completion
checks. Use functional for a concrete operation, repair, tool procedure, or
localized execution technique. Use unclassified when neither category is
supported. Never rename, merge, edit, or omit a Skill. Confidence must be a
number from 0 to 1.
"""


def skill_level_classification_user(
    skills,
    *,
    experience_root,
    run_id="",
) -> str:
    rows = []
    for skill in skills:
        rows.append(
            "NAME: {name}\nDESCRIPTION: {description}\n"
            "WORKSPACE FILE: {path}\nCONTENT EXCERPT:\n{excerpt}".format(
                name=skill["name"],
                description=skill.get("description", ""),
                path=skill.get("path", ""),
                excerpt=skill.get("excerpt", ""),
            )
        )
    return (
        f"RUN: {run_id}\n"
        f"READ-ONLY SKILL WORKSPACE: {experience_root}\n"
        "Classify every Skill below. The workspace files contain the complete "
        "SKILL.md and may be read when an excerpt is ambiguous.\n\n"
        + "\n\n--- SKILL ---\n\n".join(rows)
    )


def domain_strategy_path(domain: str) -> Optional[str]:
    name = f"reflect_{domain}.md"
    resource = files("openearth_skill_sdk").joinpath("strategies", name)
    try:
        return str(resource) if resource.is_file() else None
    except OSError:
        return None


def _strategy(lane: str, custom_path: Optional[str] = None) -> str:
    builtin = files("openearth_skill_sdk").joinpath("strategies", f"{lane}.md")
    text = builtin.read_text(encoding="utf-8")
    if custom_path:
        try:
            custom = Path(custom_path).read_text(encoding="utf-8")
        except OSError:
            custom = ""
        if custom:
            return f"{custom}\n\n{text}"
    return text


def planning_strategy(custom_path: Optional[str] = None) -> str:
    return _strategy("planning", custom_path)


def functional_strategy(custom_path: Optional[str] = None) -> str:
    return _strategy("functional", custom_path)


def curation_strategy(custom_path: Optional[str] = None) -> str:
    return _strategy("curation", custom_path)


def planning_user(
    success_ids,
    *,
    experience_root,
    out_dir,
    existing_plans="",
    run_id="",
) -> str:
    ids = "\n".join(f"  - {item}" for item in success_ids) or "  (none)"
    return (
        f"RUN: {run_id}\n"
        f"SKILL-ONLY WORKSPACE (READ-ONLY): {experience_root}\n"
        "Trajectory evidence is under trajectories/. The filename is the listed id plus .md; "
        "skills/main contains the current provider Skill snapshot. Read the evidence directly "
        "with your filesystem tools and never modify the workspace.\n\n"
        f"VERIFIED SUCCESS TRAJECTORIES:\n{ids}\n\n"
        f"CURRENT PLANNING SKILLS:\n{existing_plans or '(none)'}\n\n"
        f"Write final Planning SKILL.md files only into:\n  {out_dir}\n"
        "Writing zero files is valid."
    )


def functional_user(
    fail_id,
    signal,
    *,
    experience_root,
    out_dir,
    planning_bank,
    plan_source,
    existing_functionals="",
    run_id="",
) -> str:
    return (
        f"RUN: {run_id}\n"
        f"SKILL-ONLY WORKSPACE (READ-ONLY): {experience_root}\n"
        f"FAILED TRAJECTORY: {fail_id}\nFAILURE SIGNAL: {signal}\n"
        f"Read trajectories/{fail_id}.md directly. Never modify the workspace.\n\n"
        f"PLANNING CONTEXT (source={plan_source}):\n{planning_bank or '(none)'}\n\n"
        f"CURRENT FUNCTIONAL SKILLS:\n{existing_functionals or '(none)'}\n\n"
        f"Write at most one final Functional SKILL.md into:\n  {out_dir}\n"
        "Writing zero files is valid."
    )


def transient_user(fail_id, signal, *, experience_root) -> str:
    return (
        "Return a short transient diagnostic plan, not a Skill. Use 3–7 subgoals with "
        "completion checks. Do not write files.\n\n"
        f"FAILED TRAJECTORY: {fail_id}\nFAILURE SIGNAL: {signal}\n"
        f"Read {experience_root}/trajectories/{fail_id}.md if tools are available."
    )


def curation_user(
    *,
    candidates_dir,
    out_dir,
    existing_functionals="",
    experience_root,
    run_id="",
) -> str:
    return (
        f"RUN: {run_id}\n"
        f"Review every Functional candidate in:\n  {candidates_dir}\n\n"
        "Use each candidate's candidate_id—not its name—in curated_from. The final output "
        "may keep, edit, merge, or drop candidates. Preserve the exact source_trajs union.\n\n"
        f"SKILL-ONLY WORKSPACE (READ-ONLY): {experience_root}\n"
        f"CURRENT FUNCTIONAL SKILLS:\n{existing_functionals or '(none)'}\n\n"
        f"Write retained SKILL.md files into:\n  {out_dir}\n"
        "Finally write curation_complete.txt, including when all candidates are dropped."
    )
