"""Deterministic UX-score routing."""
from __future__ import annotations

from .contracts import TrajectoryLabel


def label_for_ux_score(score: object) -> TrajectoryLabel:
    if score is None:
        return TrajectoryLabel.DEFERRED
    if isinstance(score, bool) or not isinstance(score, int):
        raise ValueError(
            f"ux_score must be an integer in 1..10 or None, got {score!r}"
        )
    if not 1 <= score <= 10:
        raise ValueError(f"ux_score must be in 1..10, got {score}")
    if score >= 7:
        return TrajectoryLabel.SUCCESS
    if score <= 5:
        return TrajectoryLabel.FAILURE
    return TrajectoryLabel.DEFERRED
