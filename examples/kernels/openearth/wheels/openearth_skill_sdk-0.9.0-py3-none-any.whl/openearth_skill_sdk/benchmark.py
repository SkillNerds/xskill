"""OpenEarth benchmark rollout production without reflection or Gate."""
from __future__ import annotations

import hashlib
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Callable, Iterable, Optional, Union

from .config import load_config
from .contracts import (
    BenchmarkResult,
    BenchmarkTrajectory,
    ExistingSkillInput,
    TargetRun,
)
from .environments import build_environment, task_context
from .service import _classify_skill_levels
from .target import OpenCodeTargetAgent
from .workspace import DistillationWorkspace
from .xskill import _build_analyst


_STATE_FILE = "openearth-benchmark-state.json"
_STATE_SCHEMA = 1


def _settings(config: dict) -> dict:
    legacy = dict(config.get("run") or {})
    current = dict(config.get("benchmark") or {})
    merged = {**legacy, **current}
    merged["enabled"] = bool(
        current.get("enabled", legacy.get("benchmark", False))
    )
    return merged


def _state_path(workspace: Union[str, Path]) -> Path:
    return Path(workspace).expanduser().resolve() / _STATE_FILE


def _load_state(workspace: Union[str, Path]) -> dict:
    path = _state_path(workspace)
    if not path.is_file():
        return {"schema": _STATE_SCHEMA, "trajectories": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if (
        not isinstance(value, dict)
        or value.get("schema") != _STATE_SCHEMA
        or not isinstance(value.get("trajectories"), dict)
    ):
        raise ValueError(f"invalid OpenEarth benchmark state: {path}")
    return value


def _save_state(workspace: Union[str, Path], state: dict) -> None:
    path = _state_path(workspace)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(
        json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def _dataset_path(
    config_path: Union[str, Path],
    raw_value: object,
) -> Path:
    value = str(raw_value or "").strip()
    if not value:
        raise ValueError(
            "benchmark.enabled=true requires benchmark.dataset_dir"
        )
    path = Path(value).expanduser()
    if not path.is_absolute():
        path = Path(config_path).expanduser().resolve().parent / path
    path = path.resolve()
    if not path.exists():
        raise FileNotFoundError(f"benchmark dataset does not exist: {path}")
    return path


def _identity(
    *,
    dataset_path: Path,
    environment_name: str,
    split: str,
    task: dict,
    settings: dict,
) -> tuple[str, str]:
    payload = json.dumps(
        {
            "dataset_path": str(dataset_path),
            "env": environment_name,
            "split": split,
            "task": task,
            "model": str(settings.get("model") or ""),
            "sample_id": str(settings.get("sample_id") or "default"),
        },
        ensure_ascii=False,
        sort_keys=True,
        default=str,
        separators=(",", ":"),
    )
    signature = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return f"traj_oe_bench_{signature[:32]}", signature


def _platform_payload(value: object) -> str:
    return re.sub(
        r"(?m)^(\s*)##\s+",
        r"\1### ",
        str(value or "").strip(),
    )


def _markdown(task: dict, run: TargetRun) -> str:
    assistant = _platform_payload(run.transcript)
    result = "\n".join([
        "### Benchmark result",
        f"- answer: {run.answer}",
        f"- correct_answer: {run.correct_answer}",
        f"- hard: {run.hard}",
        f"- soft: {run.soft}",
        f"- selected_skills: {', '.join(run.selected_skills) or '(none)'}",
        f"- cost: {run.cost}",
        f"- error: {run.error}",
    ])
    return (
        "## User\n\n"
        f"{_platform_payload(task_context(task))}\n\n"
        "## Assistant\n\n"
        f"{assistant}\n\n{result}\n"
    )


def _failed_run(task: dict, exc: Exception) -> TargetRun:
    correct = task.get("correct_choice") or {}
    if isinstance(correct, dict):
        correct_answer = str(
            correct.get("label")
            or task.get("ground_truth")
            or task.get("answer")
            or ""
        )
    else:
        correct_answer = str(
            task.get("ground_truth") or task.get("answer") or ""
        )
    return TargetRun(
        task_id=str(task.get("id") or ""),
        answer="",
        correct_answer=correct_answer,
        hard=0,
        soft=0.0,
        transcript="",
        error=f"{type(exc).__name__}: {exc}",
    )


def _run_tasks(
    target_agent,
    tasks: list[dict],
    skills: tuple[ExistingSkillInput, ...],
    *,
    run_id: str,
    parallel: int,
    on_event,
) -> list[tuple[dict, TargetRun]]:
    def one(task: dict) -> tuple[dict, TargetRun]:
        try:
            result = target_agent.run(
                task,
                skills,
                run_id=run_id,
                phase="benchmark-probe",
            )
        except Exception as exc:  # noqa: BLE001 - preserve failed evidence
            result = _failed_run(task, exc)
        return task, result

    rows = []
    if parallel <= 1:
        for index, task in enumerate(tasks, 1):
            rows.append(one(task))
            on_event(
                "benchmark_rollout",
                progress=f"{index}/{len(tasks)}",
                task_id=str(task.get("id") or ""),
            )
        return rows

    with ThreadPoolExecutor(max_workers=parallel) as executor:
        futures = {executor.submit(one, task): task for task in tasks}
        for index, future in enumerate(as_completed(futures), 1):
            rows.append(future.result())
            on_event(
                "benchmark_rollout",
                progress=f"{index}/{len(tasks)}",
                task_id=str(futures[future].get("id") or ""),
            )
    rows.sort(key=lambda row: str(row[0].get("id") or ""))
    return rows


def run_benchmark(
    *,
    config_path: Union[str, Path],
    workspace: Union[str, Path],
    existing_skills: Iterable[ExistingSkillInput] = (),
    run_id: str,
    on_trajectory: Callable[[BenchmarkTrajectory], object],
    analyst=None,
    target_agent=None,
    environment=None,
    on_event=None,
) -> BenchmarkResult:
    """Run unseen benchmark cases and register their scored temp trajectories.

    This is a producer stage only. It never reflects, generates Skill drafts,
    publishes Skills, or executes Gate.
    """
    config = load_config(config_path)
    settings = _settings(config)
    if not settings["enabled"]:
        return BenchmarkResult(
            run_id=run_id,
            metrics={
                "benchmark_enabled": False,
                "benchmark_selected": 0,
                "benchmark_created": 0,
                "benchmark_skipped": 0,
            },
        )

    dataset_path = _dataset_path(config_path, settings.get("dataset_dir"))
    environment_name = str(settings.get("env") or "officeqa").strip().lower()
    if environment is None:
        environment = build_environment(
            environment_name,
            dataset_path,
            settings,
            workspace=workspace,
        )
    split = str(settings.get("split") or "train")
    if split not in environment.splits:
        raise ValueError(f"benchmark dataset has no split {split!r}")
    tasks = list(environment.splits[split])
    limit = settings.get("n_cases")
    if limit is not None:
        tasks = tasks[:max(0, int(limit))]

    state = _load_state(workspace)
    pending = []
    skipped = 0
    for task in tasks:
        trajectory_id, signature = _identity(
            dataset_path=dataset_path,
            environment_name=environment_name,
            split=split,
            task=task,
            settings=settings,
        )
        if trajectory_id in state["trajectories"]:
            skipped += 1
            continue
        pending.append((task, trajectory_id, signature))

    if not pending:
        return BenchmarkResult(
            run_id=run_id,
            metrics={
                "benchmark_enabled": True,
                "benchmark_selected": len(tasks),
                "benchmark_created": 0,
                "benchmark_skipped": skipped,
                "benchmark_success": 0,
                "benchmark_failure": 0,
            },
        )

    skills = tuple(existing_skills)
    skill_levels = {}
    if skills:
        distillation_workspace = DistillationWorkspace(workspace)
        snapshots = distillation_workspace.sync_main_skills(skills)
        reflect_analyst = analyst or _build_analyst(config, workspace)
        skill_levels, _classification_metrics = _classify_skill_levels(
            workspace=distillation_workspace,
            analyst=reflect_analyst,
            snapshots=snapshots,
            run_id=f"{run_id}-benchmark-classify",
        )
    if target_agent is None:
        model = str(settings.get("model") or "")
        target_agent = OpenCodeTargetAgent(
            model,
            binary=str(settings.get("binary") or "opencode"),
            timeout=float(settings.get("agent_timeout") or 900),
            planning_route_k=int(settings.get("planning_route_k") or 2),
            functional_route_k=int(settings.get("functional_route_k") or 2),
            environment=environment,
            skill_levels=skill_levels,
            workspace=Path(workspace),
        )

    emit = on_event or (lambda *_args, **_kwargs: None)
    identity_by_task = {
        id(task): (trajectory_id, signature)
        for task, trajectory_id, signature in pending
    }
    rows = _run_tasks(
        target_agent,
        [task for task, _trajectory_id, _signature in pending],
        skills,
        run_id=run_id,
        parallel=max(1, int(settings.get("parallel") or 1)),
        on_event=emit,
    )
    created = []
    success = 0
    failure = 0
    for task, run in rows:
        trajectory_id, signature = identity_by_task[id(task)]
        score = 10 if int(run.hard) else 1
        success += int(bool(run.hard))
        failure += int(not bool(run.hard))
        rollout = BenchmarkTrajectory(
            trajectory_id=trajectory_id,
            case_id=run.task_id or str(task.get("id") or ""),
            markdown=_markdown(task, run),
            ux_score=score,
            metadata={
                "env": environment_name,
                "split": split,
                "signature": signature,
                "hard": int(run.hard),
                "soft": float(run.soft),
                "answer": run.answer,
                "correct_answer": run.correct_answer,
                "selected_skills": list(run.selected_skills),
                "cost": float(run.cost),
                "error": run.error,
            },
        )
        on_trajectory(rollout)
        state["trajectories"][trajectory_id] = {
            "case_id": rollout.case_id,
            "signature": signature,
            "run_id": run_id,
            "ux_score": score,
        }
        _save_state(workspace, state)
        created.append(rollout)
    return BenchmarkResult(
        run_id=run_id,
        trajectories=tuple(created),
        metrics={
            "benchmark_enabled": True,
            "benchmark_selected": len(tasks),
            "benchmark_created": len(created),
            "benchmark_skipped": skipped,
            "benchmark_success": success,
            "benchmark_failure": failure,
        },
    )
