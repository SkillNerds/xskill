"""Minimal OfficeQA loader, local-document workspace, and EM/F1 oracle."""
from __future__ import annotations

import csv
import json
import os
import re
import shutil
import string
import tempfile
from collections import Counter
from pathlib import Path
from typing import Optional, Union

from .contracts import TargetRun


_NUMERIC_CHARS = set("0123456789.-")


def _list_field(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [
            str(item).strip()
            for item in value
            if str(item).strip()
        ]
    text = str(value).strip()
    if not text:
        return []
    try:
        loaded = json.loads(text)
    except json.JSONDecodeError:
        loaded = None
    if isinstance(loaded, list):
        return [
            str(item).strip()
            for item in loaded
            if str(item).strip()
        ]
    if "\n" in text:
        return [part.strip() for part in text.splitlines() if part.strip()]
    if "," in text and not text.lower().endswith(".txt"):
        return [part.strip() for part in text.split(",") if part.strip()]
    return [text]


def _normalize_row(row: dict) -> dict:
    item_id = str(
        row.get("uid")
        or row.get("id")
        or row.get("instance_id")
        or ""
    ).strip()
    question = str(
        row.get("question") or row.get("problem_statement") or ""
    ).strip()
    gold = str(
        row.get("ground_truth")
        or row.get("answer")
        or row.get("gold")
        or ""
    ).strip()
    task_type = str(
        row.get("category")
        or row.get("difficulty")
        or row.get("task_type")
        or "officeqa"
    ).strip()
    return {
        **row,
        "id": item_id,
        "uid": item_id,
        "question": question,
        "ground_truth": gold,
        "answers": [gold] if gold else _list_field(row.get("answers")),
        "task_type": task_type or "officeqa",
        "category": task_type or "officeqa",
        "source_files": _list_field(row.get("source_files")),
        "source_docs": _list_field(row.get("source_docs")),
        "split": str(row.get("split") or "").strip(),
    }


def _read_items(path: Path) -> list[dict]:
    if path.suffix.lower() == ".csv":
        with path.open(encoding="utf-8", newline="") as handle:
            return [_normalize_row(row) for row in csv.DictReader(handle)]
    text = path.read_text(encoding="utf-8").strip()
    if not text:
        return []
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        value = None
    if isinstance(value, list):
        return [
            _normalize_row(row)
            for row in value
            if isinstance(row, dict)
        ]
    if isinstance(value, dict):
        nested = value.get("data")
        rows = nested if isinstance(nested, list) else list(value.values())
        return [
            _normalize_row(row)
            for row in rows
            if isinstance(row, dict)
        ]
    return [
        _normalize_row(json.loads(line))
        for line in text.splitlines()
        if line.strip()
    ]


def load_tasks(path: Union[str, Path]) -> list[dict]:
    source = Path(path).expanduser()
    if not source.exists():
        raise FileNotFoundError(f"OfficeQA dataset does not exist: {source}")
    if source.is_dir():
        files = [
            file
            for pattern in ("*.csv", "*.json", "*.jsonl")
            for file in sorted(source.glob(pattern))
        ]
        if not files:
            raise FileNotFoundError(f"no OfficeQA data file under {source}")
        rows = _read_items(files[0])
    else:
        rows = _read_items(source)
    result = [
        row
        for row in rows
        if row.get("id") and row.get("question")
    ]
    if not result:
        raise ValueError(f"OfficeQA loaded no valid tasks from {source}")
    return result


def build_splits(
    path: Union[str, Path],
    *,
    n_train: Optional[int] = None,
    n_test: Optional[int] = None,
) -> dict:
    source = Path(path).expanduser()
    materialized = (
        source.is_dir()
        and (source / "train").is_dir()
        and (source / "test").is_dir()
    )
    if materialized:
        splits = {
            "train": load_tasks(source / "train"),
            "test": load_tasks(source / "test"),
        }
    else:
        splits = {"train": [], "test": []}
        for item in load_tasks(source):
            split = str(item.get("split") or "").lower()
            if split in splits:
                splits[split].append(item)
    if n_train is not None:
        splits["train"] = splits["train"][:n_train]
    if n_test is not None:
        splits["test"] = splits["test"][:n_test]
    if not splits.get("train") or not splits.get("test"):
        raise ValueError("OfficeQA requires non-empty train and test splits")
    overlap = {
        task["id"] for task in splits["train"]
    } & {
        task["id"] for task in splits["test"]
    }
    if overlap:
        raise ValueError(
            "OfficeQA train/test IDs overlap: "
            + ", ".join(sorted(overlap)[:10])
        )
    return splits


def _normalize_answer(text: str) -> str:
    text = text.lower().strip().replace(",", "")
    text = "".join(
        character
        for character in text
        if (
            character not in string.punctuation
            or character in _NUMERIC_CHARS
            or character == "%"
        )
    )
    text = re.sub(
        r"\b(million|millions|billion|billions|dollars|dollar|nominal)\b",
        " ",
        text,
    )
    return " ".join(text.split())


def _token_f1(prediction: str, gold: str) -> float:
    predicted = _normalize_answer(prediction).split()
    expected = _normalize_answer(gold).split()
    if not predicted or not expected:
        return 1.0 if predicted == expected else 0.0
    common = Counter(predicted) & Counter(expected)
    count = sum(common.values())
    if count == 0:
        return 0.0
    precision = count / len(predicted)
    recall = count / len(expected)
    return 2 * precision * recall / (precision + recall)


def _docs_roots(
    dataset_root: Path,
    configured: Optional[Union[str, list[str]]],
) -> list[Path]:
    values = []
    local = dataset_root / "docs"
    if local.is_dir():
        values.append(str(local))
    if configured:
        values.extend(
            configured.split(os.pathsep)
            if isinstance(configured, str)
            else configured
        )
    environment = os.environ.get("OFFICEQA_DOCS_DIR", "")
    if environment:
        values.extend(environment.split(os.pathsep))
    result = []
    seen = set()
    for value in values:
        for chunk in str(value).split(","):
            path = Path(chunk.strip()).expanduser()
            transformed = path / "transformed"
            root = transformed if transformed.is_dir() else path
            if root.is_dir():
                resolved = root.resolve()
                if str(resolved) not in seen:
                    seen.add(str(resolved))
                    result.append(resolved)
    return result


def _link_or_copy(source: Path, target: Path) -> None:
    try:
        os.symlink(source, target, target_is_directory=source.is_dir())
    except OSError:
        if source.is_dir():
            shutil.copytree(source, target, dirs_exist_ok=True)
        else:
            shutil.copy2(source, target)


class OfficeQAEnvironment:
    name = "officeqa"

    def __init__(
        self,
        root: Union[str, Path],
        run_config: dict,
        *,
        workspace: Optional[Union[str, Path]] = None,
    ):
        self.root = Path(root).expanduser().resolve()
        self.splits = build_splits(
            self.root,
            n_train=run_config.get("n_train"),
            n_test=run_config.get("n_test"),
        )
        self.docs_roots = _docs_roots(
            self.root,
            run_config.get("officeqa_docs_dirs"),
        )
        self.work_root = (
            Path(workspace).resolve() / "openearth-benchmark-runs"
            if workspace
            else None
        )
        if self.work_root is not None:
            self.work_root.mkdir(parents=True, exist_ok=True)

    def query(self, task: dict) -> str:
        return (
            f"{task.get('question', '')}\n"
            f"{' '.join(task.get('source_files', []))}\n"
            f"{' '.join(task.get('source_docs', []))}"
        )

    def prepare(self, task: dict) -> tuple[Path, str]:
        workdir = Path(tempfile.mkdtemp(
            prefix="oe-skill-officeqa-",
            dir=self.work_root,
        ))
        docs = workdir / "docs"
        docs.mkdir()
        for index, root in enumerate(self.docs_roots, 1):
            _link_or_copy(root, docs / f"root_{index}")
        task_parts = [
            "# OfficeQA Task",
            f"## Question\n{task.get('question', '')}",
        ]
        if task.get("source_files"):
            task_parts.append(
                "## Candidate Files\n"
                + "\n".join(
                    f"- {item}" for item in task["source_files"]
                )
            )
        if task.get("source_docs"):
            task_parts.append(
                "## Source Hints\n"
                + "\n".join(
                    f"- {item}" for item in task["source_docs"]
                )
            )
        task_parts.append(
            "## Output\nWrite only the final answer to answer.txt."
        )
        (workdir / "task.md").write_text(
            "\n\n".join(task_parts) + "\n",
            encoding="utf-8",
        )
        (workdir / "AGENTS.md").write_text(
            "Use the local files under ./docs to answer task.md. Ground the "
            "answer in evidence and write only the final answer to answer.txt.\n",
            encoding="utf-8",
        )
        prompt = (
            f"{task.get('question', '')}\n\n"
            "Read task.md and search the local docs/ corpus. Candidate files "
            "and source hints are starting points, not access limits. Write "
            "only the final answer, with no explanation, to answer.txt."
        )
        return workdir, prompt

    def score(
        self,
        task: dict,
        workdir: Path,
        *,
        transcript: str,
        selected_skills: tuple[str, ...],
        cost: float,
        process_error: str,
    ) -> TargetRun:
        answer_file = workdir / "answer.txt"
        answer = (
            answer_file.read_text(
                encoding="utf-8",
                errors="ignore",
            ).strip()
            if answer_file.is_file()
            else ""
        )
        gold = str(task.get("ground_truth") or "")
        exact = int(
            bool(answer)
            and bool(gold)
            and _normalize_answer(answer) == _normalize_answer(gold)
        )
        soft = _token_f1(answer, gold) if answer and gold else 0.0
        error = process_error
        if not error and not gold:
            error = "missing ground_truth"
        elif not error and not answer:
            error = "no answer.txt written"
        elif not error and not exact:
            error = f"predicted {answer!r} but expected {gold!r}"
        return TargetRun(
            task_id=str(task.get("id") or ""),
            answer=answer,
            correct_answer=gold,
            hard=exact,
            soft=round(float(soft), 4),
            transcript=transcript,
            selected_skills=selected_skills,
            cost=cost,
            error=error,
        )

    @staticmethod
    def cleanup(workdir: Path) -> None:
        shutil.rmtree(workdir, ignore_errors=True)

    def manifest(self) -> dict:
        return {
            "oracle": "officeqa-em-f1",
            "docs_roots": [str(path) for path in self.docs_roots],
        }
