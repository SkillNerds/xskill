"""Minimal SpreadsheetBench loader, workspace, and deterministic cell oracle."""
from __future__ import annotations

import datetime
import json
import random
import re
import shutil
import tempfile
from pathlib import Path
from typing import Optional, Union

from .contracts import TargetRun


def _cases(task: dict) -> list[tuple[str, Path, Path]]:
    directory = Path(task["_dir"])
    result = []
    for file in sorted(directory.iterdir()):
        match = re.match(r"(\d+)_.*_(init|input)\.xlsx$", file.name)
        if not match:
            continue
        number = match.group(1)
        gold = None
        for suffix in ("golden", "answer"):
            candidate = file.with_name(
                file.name.replace(
                    f"_{match.group(2)}.xlsx",
                    f"_{suffix}.xlsx",
                )
            )
            if candidate.exists():
                gold = candidate
                break
        if gold is not None:
            result.append((number, file, gold))
    return result


def load_tasks(root: Union[str, Path]) -> list[dict]:
    source = Path(root).expanduser()
    dataset_file = source / "dataset.json"
    if not dataset_file.is_file():
        raise FileNotFoundError(
            f"SpreadsheetBench dataset.json not found: {dataset_file}"
        )
    value = json.loads(dataset_file.read_text(encoding="utf-8"))
    if not isinstance(value, list):
        raise ValueError("SpreadsheetBench dataset.json must contain a list")
    result = []
    for row in value:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        directory = source / row.get(
            "spreadsheet_path",
            f"spreadsheet/{row['id']}",
        )
        task = {**row, "id": str(row["id"]), "_dir": str(directory)}
        if directory.is_dir() and _cases(task):
            result.append(task)
    if not result:
        raise ValueError(f"no runnable SpreadsheetBench tasks under {source}")
    return result


def _manifest_ids(path: Path) -> list[str]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, list):
        raise ValueError(f"split manifest must be a list: {path}")
    result = []
    for row in value:
        item_id = row.get("id") if isinstance(row, dict) else row
        if str(item_id or "").strip():
            result.append(str(item_id))
    return result


def build_splits(
    root: Union[str, Path],
    *,
    id_split: Optional[Union[str, Path]] = None,
    split_seed: int = 42,
    shuffle: bool = True,
    n_train: Optional[int] = None,
    n_test: Optional[int] = None,
) -> dict:
    tasks = load_tasks(root)
    if id_split:
        manifest_root = Path(id_split).expanduser()
        by_id = {task["id"]: task for task in tasks}
        splits = {}
        for split in ("train", "test"):
            file = manifest_root / f"{split}.json"
            if not file.is_file():
                raise FileNotFoundError(
                    f"missing SpreadsheetBench split manifest: {file}"
                )
            splits[split] = [
                by_id[item_id]
                for item_id in _manifest_ids(file)
                if item_id in by_id
            ]
    else:
        ordered = list(tasks)
        if shuffle:
            random.Random(split_seed).shuffle(ordered)
        train_count = (
            n_train
            if n_train is not None
            else max(1, len(ordered) // 2)
        )
        splits = {
            "train": ordered[:train_count],
            "test": ordered[train_count:],
        }
    if n_train is not None:
        splits["train"] = splits["train"][:n_train]
    if n_test is not None:
        splits["test"] = splits["test"][:n_test]
    if not splits.get("train") or not splits.get("test"):
        raise ValueError(
            "SpreadsheetBench requires non-empty train and test splits"
        )
    overlap = {
        task["id"] for task in splits["train"]
    } & {
        task["id"] for task in splits["test"]
    }
    if overlap:
        raise ValueError(
            "SpreadsheetBench train/test IDs overlap: "
            + ", ".join(sorted(overlap)[:10])
        )
    return splits


def _datetime_to_float(value: datetime.datetime) -> float:
    delta = value - datetime.datetime(1899, 12, 30)
    return delta.days + delta.seconds / 86400.0


def _transform_value(value):
    if isinstance(value, (int, float)):
        return round(float(value), 2)
    if isinstance(value, datetime.time):
        return str(value)[:-3]
    if isinstance(value, datetime.datetime):
        return round(_datetime_to_float(value), 0)
    if isinstance(value, str):
        try:
            return round(float(value), 2)
        except ValueError:
            return value
    return value


def _same_value(left, right) -> bool:
    left, right = _transform_value(left), _transform_value(right)
    if (left == "" or left is None) and (right == "" or right is None):
        return True
    return type(left) is type(right) and left == right


def _column_name(number: int) -> str:
    result = ""
    while number > 0:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result


def _column_number(name: str) -> int:
    result = 0
    for character in name:
        result = result * 26 + (ord(character.upper()) - 64)
    return result


def _cell_names(
    cell_range: str,
    max_row: Optional[int] = None,
    max_column: Optional[int] = None,
) -> list[str]:
    if ":" not in cell_range:
        return [cell_range]
    start, end = cell_range.split(":", 1)
    start_column = "".join(c for c in start if not c.isdigit()) or "A"
    start_row = "".join(c for c in start if c.isdigit()) or "1"
    end_column = (
        "".join(c for c in end if not c.isdigit())
        or _column_name(max_column or 26)
    )
    end_row = (
        "".join(c for c in end if c.isdigit())
        or str(max_row or 1000)
    )
    return [
        f"{_column_name(column)}{row}"
        for column in range(
            _column_number(start_column),
            _column_number(end_column) + 1,
        )
        for row in range(int(start_row), int(end_row) + 1)
    ]


def compare_workbooks(
    gold_file: Union[str, Path],
    output_file: Union[str, Path],
    answer_position: str,
    answer_sheet: str = "",
) -> tuple[bool, str]:
    import openpyxl

    output = Path(output_file)
    if not output.is_file():
        return False, "output workbook not found"
    try:
        gold_book = openpyxl.load_workbook(
            filename=gold_file,
            data_only=True,
        )
        output_book = openpyxl.load_workbook(
            filename=output,
            data_only=True,
        )
    except Exception as exc:  # noqa: BLE001
        return False, f"error loading workbook: {exc}"
    for raw_range in str(answer_position).split(","):
        raw_range = raw_range.strip().strip("'")
        if "!" in raw_range:
            sheet, cells = raw_range.split("!", 1)
            sheet = sheet.strip("'")
        else:
            sheet = answer_sheet or gold_book.sheetnames[0]
            cells = raw_range
        if sheet not in gold_book.sheetnames:
            sheet = gold_book.sheetnames[0]
        if sheet not in output_book.sheetnames:
            return False, f"worksheet {sheet!r} not found in output"
        gold_sheet = gold_book[sheet]
        output_sheet = output_book[sheet]
        for cell in _cell_names(
            cells.strip("'"),
            gold_sheet.max_row,
            gold_sheet.max_column,
        ):
            if not _same_value(
                gold_sheet[cell].value,
                output_sheet[cell].value,
            ):
                return (
                    False,
                    f"mismatch at {sheet}!{cell}: expected "
                    f"{gold_sheet[cell].value!r}, got "
                    f"{output_sheet[cell].value!r}",
                )
    return True, ""


class SpreadsheetEnvironment:
    name = "spreadsheet"

    def __init__(
        self,
        root: Union[str, Path],
        run_config: dict,
        *,
        workspace: Optional[Union[str, Path]] = None,
    ):
        id_split = run_config.get("id_split") or None
        if id_split and not Path(str(id_split)).expanduser().is_absolute():
            id_split = Path(root) / str(id_split)
        self.splits = build_splits(
            root,
            id_split=id_split,
            split_seed=int(run_config.get("split_seed") or 42),
            shuffle=run_config.get("shuffle", True) is not False,
            n_train=run_config.get("n_train"),
            n_test=run_config.get("n_test"),
        )
        self.work_root = (
            Path(workspace).resolve() / "openearth-benchmark-runs"
            if workspace
            else None
        )
        if self.work_root is not None:
            self.work_root.mkdir(parents=True, exist_ok=True)

    def query(self, task: dict) -> str:
        return (
            f"{task.get('instruction', '')}\n"
            f"sheet={task.get('answer_sheet', '')} "
            f"range={task.get('answer_position', '')}"
        )

    def prepare(self, task: dict) -> tuple[Path, str]:
        workdir = Path(tempfile.mkdtemp(
            prefix="oe-skill-xlsx-",
            dir=self.work_root,
        ))
        numbers = []
        for number, input_file, _gold in _cases(task):
            shutil.copy2(input_file, workdir / f"{number}_input.xlsx")
            numbers.append(number)
        inputs = ", ".join(f"{number}_input.xlsx" for number in numbers)
        prompt = (
            f"{task.get('instruction', '')}\n\n"
            "The current directory contains numbered input workbooks: "
            f"{inputs}. For every k_input.xlsx, apply the instruction and save "
            "the completed workbook as k_output.xlsx. Use Python with openpyxl "
            "or pandas. Preserve unrelated sheets and cells. Do not rename "
            f"sheets. The checked target is {task.get('answer_position', '')} "
            f"on sheet {task.get('answer_sheet', '') or 'the relevant sheet'}."
        )
        return workdir, prompt

    def score(
        self,
        task: dict,
        workdir: Path,
        *,
        transcript: str,
        selected_skills: tuple[str, ...],
        cost: float,
        process_error: str,
    ) -> TargetRun:
        cases = _cases(task)
        passed = 0
        first_failure = process_error
        produced = []
        for number, _input, gold in cases:
            output = workdir / f"{number}_output.xlsx"
            if output.is_file():
                produced.append(output.name)
            ok, message = compare_workbooks(
                gold,
                output,
                str(task.get("answer_position") or ""),
                str(task.get("answer_sheet") or ""),
            )
            if ok:
                passed += 1
            elif not first_failure:
                first_failure = f"case {number}: {message}"
        soft = passed / len(cases) if cases else 0.0
        return TargetRun(
            task_id=str(task.get("id") or ""),
            answer=json.dumps(produced),
            correct_answer=str(task.get("answer_position") or ""),
            hard=int(bool(cases) and passed == len(cases)),
            soft=round(soft, 4),
            transcript=transcript,
            selected_skills=selected_skills,
            cost=cost,
            error=first_failure,
        )

    @staticmethod
    def cleanup(workdir: Path) -> None:
        shutil.rmtree(workdir, ignore_errors=True)

    @staticmethod
    def manifest() -> dict:
        return {"oracle": "spreadsheet-cell-compare"}
