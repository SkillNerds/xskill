"""Experience-free layered Planning → Functional → curate pipeline."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from .analyst import slug
from .contracts import ExistingSkillInput, ScoredAtomInput, TrajectoryLabel
from .frontmatter import parse_strict
from .workspace import DistillationWorkspace


_OPTIMIZER_FIELDS = (
    "kind",
    "level",
    "target_subgoal",
    "planning_context",
    "plan_source",
    "source_steps",
    "verified",
    "source_type",
    "status",
    "scope",
    "promotion_target",
    "applicable_plans",
    "promotion_exceptions",
    "promoted_from",
)


@dataclass(frozen=True)
class Evidence:
    internal_id: str
    source: ScoredAtomInput
    label: TrajectoryLabel

    @property
    def task_id(self) -> str:
        return self.source.atom_id

    @property
    def query(self) -> str:
        return (
            f"{self.source.atom_id} {self.source.intent} "
            f"{self.source.summary} {self.source.content[:2000]}"
        )


def _terms(text: str) -> set[str]:
    lowered = (text or "").lower()
    return set(re.findall(r"[a-z0-9]+", lowered)) | set(
        re.findall(r"[\u3400-\u9fff]", lowered)
    )


def _metadata(frontmatter: dict, key: str, default=None):
    nested = (
        frontmatter.get("metadata")
        if isinstance(frontmatter.get("metadata"), dict)
        else {}
    )
    return frontmatter.get(key, nested.get(key, default))


def _skill_records(
    snapshots: dict[str, ExistingSkillInput],
    skill_levels: dict[str, str],
) -> list[dict]:
    records = []
    for name, snapshot in snapshots.items():
        frontmatter, body = parse_strict(snapshot.skill_md)
        record = {
            "name": name,
            "description": frontmatter.get("description", ""),
            "body": body,
            "source_trajs": list(_metadata(frontmatter, "source_trajs", []) or []),
        }
        for key in _OPTIMIZER_FIELDS:
            value = _metadata(frontmatter, key)
            if value is not None:
                record[key] = value
        if not str(record.get("level") or "").strip():
            record["level"] = skill_levels.get(name, "unclassified")
        records.append(record)
    return records


def _summaries(skills: list[dict]) -> str:
    return "\n".join(
        f"- {item['name']}: {item.get('description', '')}\n"
        f"  {item.get('body', '')[:500]}"
        for item in skills
    )


def _dedupe(candidates: list[dict]) -> list[dict]:
    seen: dict[tuple[str, str, str], dict] = {}
    result = []
    for raw in candidates or []:
        item = dict(raw)
        key = (
            str(item.get("level") or ""),
            slug(item.get("name", "")),
            " ".join(str(item.get("body") or "").split()),
        )
        if key in seen:
            previous = seen[key]
            previous["source_trajs"] = list(
                dict.fromkeys(
                    list(previous.get("source_trajs", []) or [])
                    + list(item.get("source_trajs", []) or [])
                )
            )
            continue
        item["name"] = slug(item.get("name", ""))
        seen[key] = item
        result.append(item)
    return result


class LayeredSkillPipeline:
    """Run only the reflect lanes required by the external Skill SDK."""

    def __init__(
        self,
        *,
        workspace: DistillationWorkspace,
        analyst,
        strategy_path: Optional[str] = None,
        on_event=None,
    ) -> None:
        self.workspace = workspace
        self.analyst = analyst
        self.strategy_path = strategy_path
        self.on_event = on_event or (lambda *_args, **_kwargs: None)

    def _emit(self, kind: str, **data) -> None:
        self.on_event(kind, **data)

    @staticmethod
    def _validate(
        raw: dict,
        *,
        expected_level: str,
        known_ids: set[str],
        lane_ids: set[str],
    ) -> Optional[dict]:
        candidate = dict(raw)
        name = slug(candidate.get("name", ""))
        description = " ".join(
            str(candidate.get("description") or "").split()
        ).strip()[:300]
        body = str(candidate.get("body") or "").strip()
        level = str(candidate.get("level") or expected_level).strip().lower()
        declared = candidate.get("source_trajs", [])
        valid_sources = candidate.get(
            "_source_trajs_valid",
            isinstance(declared, list)
            and bool(declared)
            and all(
                isinstance(item, str) and item.strip() for item in declared
            ),
        )
        sources = (
            list(dict.fromkeys(item.strip() for item in declared))
            if valid_sources
            else []
        )
        if (
            not name
            or not description
            or not body
            or level != expected_level
            or not sources
            or not set(sources).issubset(known_ids)
            or not set(sources).intersection(lane_ids)
        ):
            return None
        if expected_level == "functional":
            steps = candidate.get("source_steps", [])
            if (
                not candidate.get("target_subgoal")
                or not isinstance(steps, list)
                or not steps
                or not all(
                    isinstance(step, int)
                    and not isinstance(step, bool)
                    and step >= 0
                    for step in steps
                )
            ):
                return None
        candidate.update(
            name=name,
            description=description,
            body=body,
            kind="leaf",
            level=expected_level,
            source_type=(
                "success" if expected_level == "planning" else "failure"
            ),
            source_trajs=sources,
        )
        if expected_level == "functional":
            candidate["verified"] = False
        return candidate

    @staticmethod
    def _retrieve_plans(
        failure: Evidence,
        plans: list[dict],
        evidence_by_id: dict[str, Evidence],
        limit: int = 3,
    ) -> list[dict]:
        query_terms = _terms(failure.query)
        ranked = []
        for plan in plans:
            same_task = any(
                evidence_by_id[source_id].task_id == failure.task_id
                for source_id in plan.get("source_trajs", [])
                if source_id in evidence_by_id
            )
            text = (
                f"{plan.get('name', '')} {plan.get('description', '')} "
                f"{plan.get('body', '')}"
            )
            overlap = len(query_terms & _terms(text))
            ranked.append(
                (
                    1 if same_task else 0,
                    overlap,
                    str(plan.get("name") or ""),
                    plan,
                )
            )
        ranked.sort(key=lambda row: row[:3], reverse=True)
        return [
            row[-1]
            for row in ranked
            if row[0] or row[1]
        ][:limit]

    @staticmethod
    def _curation(
        originals: list[dict],
        curated,
    ) -> tuple[list[dict], str]:
        if curated is None:
            return originals, "failed-open"
        by_id = {item["candidate_id"]: item for item in originals}
        used: set[str] = set()
        checked = []
        for candidate in _dedupe(curated):
            origins = candidate.get("curated_from", [])
            valid = (
                isinstance(origins, list)
                and bool(origins)
                and len(origins) == len(set(origins))
                and all(origin in by_id for origin in origins)
                and not used.intersection(origins)
                and candidate.get("level") == "functional"
            )
            if not valid:
                return originals, "invalid-failed-open"
            sources = set()
            contexts = []
            steps = []
            plan_sources = []
            for origin in origins:
                source = by_id[origin]
                sources.update(source.get("source_trajs", []) or [])
                contexts.extend(source.get("planning_context", []) or [])
                steps.extend(source.get("source_steps", []) or [])
                if source.get("plan_source"):
                    plan_sources.append(source["plan_source"])
            if set(candidate.get("source_trajs", []) or []) != sources:
                return originals, "invalid-failed-open"
            candidate["planning_context"] = list(dict.fromkeys(contexts))
            candidate["source_steps"] = sorted(set(steps))
            candidate["plan_source"] = (
                plan_sources[0]
                if plan_sources and len(set(plan_sources)) == 1
                else "mixed"
            )
            candidate["verified"] = False
            candidate["source_type"] = "failure"
            candidate["candidate_id"] = (
                f"curated-{len(checked):04d}-{slug(candidate.get('name', 'candidate'))}"
            )
            used.update(origins)
            checked.append(candidate)
        return checked, "complete"

    def run(
        self,
        *,
        run_id: str,
        evidence: list[Evidence],
        snapshots: dict[str, ExistingSkillInput],
        skill_levels: dict[str, str],
    ) -> tuple[list[dict], str, dict]:
        run_dir = self.workspace.start_candidate_run(run_id)
        evidence_by_id = {item.internal_id: item for item in evidence}
        known_ids = set(evidence_by_id)
        successes = [
            item for item in evidence if item.label == TrajectoryLabel.SUCCESS
        ]
        failures = [
            item for item in evidence if item.label == TrajectoryLabel.FAILURE
        ]
        records = _skill_records(snapshots, skill_levels)
        existing_plans = [
            item
            for item in records
            if item.get("kind", "leaf") == "leaf"
            and item.get("level", "unclassified") == "planning"
        ]
        existing_functionals = [
            item
            for item in records
            if item.get("kind", "leaf") == "leaf"
            and item.get("level", "unclassified") == "functional"
        ]

        success_ids = [item.internal_id for item in successes]
        planning_raw = self.analyst.distill_plans(
            success_ids,
            existing_plans=_summaries(existing_plans),
            strategy_path=self.strategy_path,
            experience_root=self.workspace.experience_root,
            run_id=run_id,
            round_idx=1,
            shard_idx=0,
            n_shards=1,
        ) if success_ids else []
        planning = []
        for raw in _dedupe(planning_raw or []):
            candidate = self._validate(
                raw,
                expected_level="planning",
                known_ids=known_ids,
                lane_ids=set(success_ids),
            )
            if candidate is not None:
                planning.append(candidate)
        self._emit(
            "reflect_planning",
            run_id=run_id,
            trajectories=len(successes),
            candidates=len(planning),
        )

        planning_bank = existing_plans + planning
        functional_raw = []
        plan_source_counts = {
            "same_task_success": 0,
            "retrieved_success": 0,
            "transient_pseudo_plan": 0,
        }
        for failure in failures:
            plans = self._retrieve_plans(
                failure,
                planning_bank,
                evidence_by_id,
            )
            if plans:
                same_task = any(
                    evidence_by_id[source_id].task_id == failure.task_id
                    for plan in plans
                    for source_id in plan.get("source_trajs", [])
                    if source_id in evidence_by_id
                )
                plan_source = (
                    "same_task_success" if same_task else "retrieved_success"
                )
                planning_context = _summaries(plans)
                plan_names = [plan["name"] for plan in plans]
            else:
                plan_source = "transient_pseudo_plan"
                planning_context = self.analyst.make_transient_plan(
                    failure.internal_id,
                    signal=(
                        f"UX score {failure.source.ux_score}/10 indicates a "
                        "failed or partial task"
                    ),
                    experience_root=self.workspace.experience_root,
                    run_id=run_id,
                    round_idx=1,
                )
                plan_names = []
            generated = self.analyst.reflect_functionals(
                [(
                    failure.internal_id,
                    f"UX score {failure.source.ux_score}/10",
                )],
                planning_bank=planning_context,
                plan_source=plan_source,
                existing_functionals=_summaries(existing_functionals),
                strategy_path=self.strategy_path,
                experience_root=self.workspace.experience_root,
                run_id=run_id,
                round_idx=1,
            )
            for raw in _dedupe(generated or []):
                raw["planning_context"] = list(plan_names)
                raw["plan_source"] = plan_source
                candidate = self._validate(
                    raw,
                    expected_level="functional",
                    known_ids=known_ids,
                    lane_ids={failure.internal_id},
                )
                if candidate is not None:
                    candidate["candidate_id"] = (
                        f"candidate-{len(functional_raw):04d}-"
                        f"{slug(candidate['name'])}"
                    )
                    functional_raw.append(candidate)
                    plan_source_counts[plan_source] += 1

        curated_response = self.analyst.curate_functionals(
            functional_raw,
            existing_functionals=_summaries(existing_functionals),
            strategy_path=self.strategy_path,
            experience_root=self.workspace.experience_root,
            run_id=run_id,
            round_idx=1,
        ) if functional_raw else []
        functional, curation_status = self._curation(
            functional_raw,
            curated_response,
        )
        self._emit(
            "reflect_functional_curation",
            run_id=run_id,
            inputs=len(functional_raw),
            outputs=len(functional),
            status=curation_status,
        )

        candidates = planning + functional
        for candidate in candidates:
            self.workspace.save_candidate(run_dir, candidate)
        metrics = {
            "planning_candidates": len(planning),
            "functional_candidates_before_curation": len(functional_raw),
            "functional_candidates": len(functional),
            "functional_curation_status": curation_status,
            "functional_plan_sources": plan_source_counts,
        }
        return candidates, str(run_dir), metrics
