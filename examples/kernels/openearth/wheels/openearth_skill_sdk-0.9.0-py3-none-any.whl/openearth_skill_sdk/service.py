"""Persistent Atom-based Skill training service."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable, Optional, Union

from .contracts import (
    DistillationResult,
    ExistingSkillInput,
    ScoredAtomInput,
    SkillDraft,
    TrajectoryLabel,
)
from .analyst import slug
from .frontmatter import parse_strict, serialize
from .labels import label_for_ux_score
from .pipeline import Evidence, LayeredSkillPipeline
from .workspace import DistillationWorkspace, OPTIMIZER_FIELDS


_SKILL_LEVELS = {"planning", "functional", "unclassified"}
_SKILL_LEVEL_CONFIDENCE = 0.7


def _declared_skill_level(skill_md: str) -> Optional[str]:
    frontmatter, _body = parse_strict(skill_md)
    metadata = (
        frontmatter.get("metadata")
        if isinstance(frontmatter.get("metadata"), dict)
        else {}
    )
    raw = (
        frontmatter.get("level")
        if frontmatter.get("level") not in ("", None)
        else metadata.get("level")
    )
    value = str(raw or "").strip().lower()
    return value or None


def _skill_version_key(snapshot: ExistingSkillInput) -> str:
    if snapshot.version_token:
        return f"version:{snapshot.version_token}"
    digest = hashlib.sha256()
    digest.update(snapshot.skill_md.encode("utf-8"))
    for relative, content in sorted(snapshot.files.items()):
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(content.encode("utf-8"))
        digest.update(b"\0")
    return f"content:{digest.hexdigest()}"


def _classify_skill_levels(
    *,
    workspace: DistillationWorkspace,
    analyst,
    snapshots: dict[str, ExistingSkillInput],
    run_id: str,
) -> tuple[dict[str, str], dict]:
    levels: dict[str, str] = {}
    metrics = {
        "existing_skills": len(snapshots),
        "skill_levels_explicit": 0,
        "skill_level_cache_hits": 0,
        "skill_level_classification_calls": 0,
        "skill_levels_model_classified": 0,
        "skill_levels_unclassified": 0,
        "skill_level_missing_results": 0,
    }
    cache = workspace.load_skill_classifications()
    cached_rows = cache["skills"]
    next_cache = {}
    pending = []

    for name, snapshot in snapshots.items():
        declared = _declared_skill_level(snapshot.skill_md)
        if declared:
            levels[name] = declared
            metrics["skill_levels_explicit"] += 1
            continue
        version_key = _skill_version_key(snapshot)
        cached = cached_rows.get(name)
        cached_level = (
            str(cached.get("level") or "").strip().lower()
            if isinstance(cached, dict)
            else ""
        )
        if (
            isinstance(cached, dict)
            and cached.get("version_key") == version_key
            and cached_level in _SKILL_LEVELS
        ):
            levels[name] = cached_level
            next_cache[name] = cached
            metrics["skill_level_cache_hits"] += 1
            continue
        frontmatter, body = parse_strict(snapshot.skill_md)
        pending.append({
            "name": name,
            "description": str(frontmatter.get("description") or ""),
            "excerpt": body.strip()[:4000],
            "path": str(
                workspace.main_skills_root / slug(name) / "SKILL.md"
            ),
            "version_key": version_key,
        })

    classify = getattr(analyst, "classify_skills", None)
    returned = []
    if pending and callable(classify):
        metrics["skill_level_classification_calls"] = 1
        returned = classify(
            pending,
            experience_root=workspace.experience_root,
            run_id=run_id,
        ) or []
    by_name = {}
    pending_names = {item["name"] for item in pending}
    for raw in returned:
        if not isinstance(raw, dict):
            continue
        name = str(raw.get("name") or "")
        if name not in pending_names or name in by_name:
            continue
        by_name[name] = raw

    for item in pending:
        name = item["name"]
        raw = by_name.get(name)
        if raw is None:
            levels[name] = "unclassified"
            metrics["skill_level_missing_results"] += 1
            continue
        proposed = str(raw.get("level") or "").strip().lower()
        confidence_value = raw.get("confidence")
        confidence = (
            float(confidence_value)
            if isinstance(confidence_value, (int, float))
            and not isinstance(confidence_value, bool)
            else -1.0
        )
        level = (
            proposed
            if proposed in {"planning", "functional"}
            and _SKILL_LEVEL_CONFIDENCE <= confidence <= 1.0
            else "unclassified"
        )
        levels[name] = level
        next_cache[name] = {
            "version_key": item["version_key"],
            "level": level,
            "proposed_level": (
                proposed if proposed in _SKILL_LEVELS else "unclassified"
            ),
            "confidence": confidence,
            "reason": " ".join(
                str(raw.get("reason") or "").split()
            )[:500],
        }
        if level in {"planning", "functional"}:
            metrics["skill_levels_model_classified"] += 1

    metrics["skill_levels_unclassified"] = sum(
        1 for value in levels.values() if value == "unclassified"
    )
    next_value = {"schema": 1, "skills": next_cache}
    if next_value != cache:
        workspace.save_skill_classifications(next_value)
    return levels, metrics


def _signature(atom: ScoredAtomInput) -> str:
    value = json.dumps(
        {
            "evidence_id": atom.evidence_id,
            "content": atom.content,
            "ux_score": atom.ux_score,
            "score_source": atom.score_source,
            "intent": atom.intent,
            "summary": atom.summary,
            "used_skills": list(atom.used_skills),
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _internal_id(atom: ScoredAtomInput) -> str:
    digest = hashlib.sha256(
        atom.evidence_id.encode("utf-8")
    ).hexdigest()[:24]
    return f"xskill-atom-{digest}"


class TrajectorySkillDistiller:
    """Generate curated candidates without dataset rollout or publication."""

    def __init__(
        self,
        *,
        workspace: Union[str, Path],
        analyst,
        strategy_path: Optional[str] = None,
        on_event=None,
    ) -> None:
        if analyst is None:
            raise ValueError("a configured OpenEarth reflect analyst is required")
        self.workspace = DistillationWorkspace(workspace)
        self.pipeline = LayeredSkillPipeline(
            workspace=self.workspace,
            analyst=analyst,
            strategy_path=strategy_path,
            on_event=on_event,
        )

    def distill(
        self,
        atoms: Iterable[ScoredAtomInput],
        existing_skills: Iterable[ExistingSkillInput] = (),
        *,
        run_id: str,
        full_rebuild: bool = False,
    ) -> DistillationResult:
        snapshots = self.workspace.sync_main_skills(existing_skills)
        state = self.workspace.load_state()
        prior = state["trajectories"]
        observed = []
        metrics = {
            "selected": 0,
            "scored_eligible": 0,
            "labeled_success": 0,
            "labeled_failure": 0,
            "ux6_deferred": 0,
            "unscored_deferred": 0,
            "invalid_score": 0,
            "xskill_scores": 0,
            "oracle_scores": 0,
            "unchanged": 0,
            "rescored_or_changed": 0,
            "historical_reprocessed": 0,
            "batch_duplicates": 0,
            "full_rebuild": bool(full_rebuild),
            "existing_skills": len(snapshots),
            "skill_levels_explicit": 0,
            "skill_level_cache_hits": 0,
            "skill_level_classification_calls": 0,
            "skill_levels_model_classified": 0,
            "skill_levels_unclassified": 0,
            "skill_level_missing_results": 0,
        }
        seen_in_run = {}
        for atom in atoms:
            metrics["selected"] += 1
            if not atom.atom_id:
                raise ValueError("ScoredAtomInput.atom_id must not be empty")
            signature = _signature(atom)
            previous_signature = seen_in_run.get(atom.atom_id)
            if previous_signature is not None:
                if previous_signature == signature:
                    metrics["batch_duplicates"] += 1
                    continue
                raise ValueError(
                    "conflicting duplicate atom_id in one training batch: "
                    f"{atom.atom_id!r}"
                )
            seen_in_run[atom.atom_id] = signature
            old = prior.get(atom.evidence_id)
            changed = (
                bool(full_rebuild)
                or not old
                or old.get("signature") != signature
            )
            if not changed:
                metrics["unchanged"] += 1
                continue
            if old:
                if full_rebuild:
                    metrics["historical_reprocessed"] += 1
                else:
                    metrics["rescored_or_changed"] += 1
            try:
                label = label_for_ux_score(atom.ux_score)
            except ValueError:
                label = None
                metrics["invalid_score"] += 1
            if label == TrajectoryLabel.SUCCESS:
                metrics["labeled_success"] += 1
                metrics["scored_eligible"] += 1
            elif label == TrajectoryLabel.FAILURE:
                metrics["labeled_failure"] += 1
                metrics["scored_eligible"] += 1
            elif atom.ux_score == 6:
                metrics["ux6_deferred"] += 1
            else:
                metrics["unscored_deferred"] += 1
            if atom.ux_score is not None:
                metrics[f"{atom.score_source}_scores"] += 1
            observed.append((atom, label, signature))

        eligible = [
            (atom, label, signature)
            for atom, label, signature in observed
            if label in (TrajectoryLabel.SUCCESS, TrajectoryLabel.FAILURE)
        ]
        if not eligible:
            for atom, label, signature in observed:
                prior[atom.evidence_id] = {
                    "signature": signature,
                    "status": (label or TrajectoryLabel.DEFERRED).value,
                    "ux_score": atom.ux_score,
                    "score_source": atom.score_source,
                }
            self.workspace.save_state(state)
            return DistillationResult(
                run_id=run_id,
                candidate_dir=None,
                metrics=metrics,
                notes="no new scored Atom was eligible for reflection",
            )

        evidence = []
        source_by_internal_id = {}
        for atom, label, _signature_value in eligible:
            internal_id = _internal_id(atom)
            item = Evidence(
                internal_id=internal_id,
                source=atom,
                label=label,
            )
            evidence.append(item)
            source_by_internal_id[internal_id] = atom
            self.workspace.materialize_trajectory(
                internal_id=internal_id,
                resource_id=atom.evidence_id,
                trajectory_id=atom.parent_trajectory_id,
                content=atom.content,
                ux_score=int(atom.ux_score),
                label=label.value,
                intent=atom.intent,
                summary=atom.summary,
                used_skills=atom.used_skills,
                metadata={
                    **dict(atom.metadata),
                    "atom_id": atom.atom_id,
                    "score_source": atom.score_source,
                },
            )

        skill_levels, classification_metrics = _classify_skill_levels(
            workspace=self.workspace,
            analyst=self.pipeline.analyst,
            snapshots=snapshots,
            run_id=run_id,
        )
        metrics.update(classification_metrics)
        candidates, candidate_dir, pipeline_metrics = self.pipeline.run(
            run_id=run_id,
            evidence=evidence,
            snapshots=snapshots,
            skill_levels=skill_levels,
        )
        drafts = []
        for candidate in candidates:
            sources = [
                source_by_internal_id[source_id]
                for source_id in candidate.get("source_trajs", [])
                if source_id in source_by_internal_id
            ]
            if not sources:
                continue
            snapshot = snapshots.get(candidate["name"])
            if snapshot:
                frontmatter, _old_body = parse_strict(snapshot.skill_md)
            else:
                frontmatter = {}
            frontmatter.update(
                name=candidate["name"],
                description=candidate["description"],
            )
            for key in OPTIMIZER_FIELDS:
                if key in candidate:
                    frontmatter[key] = candidate[key]
            for private in (
                "source_trajs",
                "reasoning",
                "curated_from",
                "candidate_id",
                "gate",
            ):
                frontmatter.pop(private, None)
            drafts.append(
                SkillDraft(
                    name=candidate["name"],
                    skill_md=serialize(frontmatter, candidate["body"]),
                    files=dict(snapshot.files) if snapshot else {},
                    source_trajectory_ids=tuple(
                        dict.fromkeys(
                            source.parent_trajectory_id for source in sources
                        )
                    ),
                    action="update" if snapshot else "create",
                    base_version_token=(
                        snapshot.version_token if snapshot else None
                    ),
                )
            )

        for atom, label, signature in observed:
            prior[atom.evidence_id] = {
                "signature": signature,
                "status": (label or TrajectoryLabel.DEFERRED).value,
                "ux_score": atom.ux_score,
                "score_source": atom.score_source,
                "run_id": run_id,
            }
        self.workspace.save_state(state)
        return DistillationResult(
            run_id=run_id,
            candidate_dir=candidate_dir,
            drafts=tuple(drafts),
            processed_trajectory_ids=tuple(
                dict.fromkeys(
                    atom.parent_trajectory_id
                    for atom, _label, _signature_value in eligible
                )
            ),
            processed_atom_ids=tuple(
                atom.evidence_id
                for atom, _label, _signature_value in eligible
            ),
            metrics={
                **metrics,
                **pipeline_metrics,
                "drafts": len(drafts),
            },
            notes="curated candidates generated; XSkill owns publication",
        )
