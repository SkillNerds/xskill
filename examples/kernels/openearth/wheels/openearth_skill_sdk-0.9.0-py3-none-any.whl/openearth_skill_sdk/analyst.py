"""Standalone OpenEarth reflect analyst used by the minimal SDK."""
from __future__ import annotations

import logging
import json
import re
import tempfile
from pathlib import Path
from typing import Optional, Tuple, Union

from . import prompts
from .backend import AgentRequest, ensure_backend
from .frontmatter import FrontmatterError, parse_strict, serialize


_LOG = logging.getLogger(__name__)
_SLUG = re.compile(r"[^a-z0-9-]+")
_FENCED = re.compile(
    r"(?:```|~~~)(?:markdown|md|skill)?\s*\n(?P<body>---\n.*?)(?:```|~~~)",
    re.DOTALL | re.IGNORECASE,
)
_JSON_FENCED = re.compile(
    r"(?:```|~~~)(?:json)?\s*\n(?P<body>.*?)(?:```|~~~)",
    re.DOTALL | re.IGNORECASE,
)


def slug(value: str) -> str:
    return _SLUG.sub("-", str(value or "").lower()).strip("-")[:80] or "skill"


def _repair_plain_reasoning(text: str) -> Optional[Tuple[dict, str, str]]:
    lines = text.split("\n")
    closing = next(
        (index for index in range(1, len(lines)) if lines[index].strip() == "---"),
        -1,
    )
    candidates = []
    for index in range(1, closing if closing >= 0 else 0):
        if lines[index].startswith("reasoning:"):
            raw = lines[index].split(":", 1)[1].strip()
            if raw and raw not in ("|", "|-", "|+", ">", ">-", ">+"):
                candidates.append((index, raw))
    if len(candidates) != 1:
        return None
    index, raw = candidates[0]
    lines[index] = "reasoning: ''"
    frontmatter, body = parse_strict("\n".join(lines))
    frontmatter["reasoning"] = raw
    return frontmatter, body, serialize(frontmatter, body)


def _response_documents(text: str) -> list[str]:
    fenced = [match.group("body").strip() for match in _FENCED.finditer(text or "")]
    if fenced:
        return fenced
    stripped = (text or "").strip()
    return [stripped] if stripped.startswith("---\n") else []


class Analyst:
    """Generate Planning/Functional files through an injected reflect backend."""

    def __init__(
        self,
        backend,
        *,
        log_root: Optional[Union[str, Path]] = None,
    ) -> None:
        self.backend = ensure_backend(backend)
        self.log_root = Path(log_root).resolve() if log_root else None

    def _log_path(self, run_id: str, lane: str) -> Optional[str]:
        if self.log_root is None:
            return None
        return str(self.log_root / slug(run_id) / f"{lane}.jsonl")

    def _run_file_pass(
        self,
        *,
        instructions: str,
        user_input: str,
        lane: str,
        run_id: str,
        scratch: Path,
        output: Path,
    ) -> list[dict]:
        output.mkdir(parents=True, exist_ok=True)
        try:
            result = self.backend.run(
                AgentRequest(
                    instructions=instructions,
                    user_input=user_input,
                    workdir=scratch,
                    output_dir=output,
                    metadata={"log_path": self._log_path(run_id, lane)},
                )
            )
        except Exception:
            _LOG.exception("reflect lane failed: %s", lane)
            return []
        files = sorted(output.glob("*.md"))
        if files:
            return self._read_skill_files(files)
        documents = _response_documents(result.text)
        return self._read_skill_texts(documents, lane=lane)

    def classify_skills(
        self,
        skills,
        *,
        experience_root=None,
        run_id=None,
        **_kwargs,
    ):
        """Classify one batch of provider Skills with one backend invocation."""
        rows = list(skills or [])
        if not rows:
            return []
        try:
            result = self.backend.run(
                AgentRequest(
                    instructions=prompts.SKILL_LEVEL_CLASSIFICATION_INSTRUCTIONS,
                    user_input=prompts.skill_level_classification_user(
                        rows,
                        experience_root=experience_root,
                        run_id=str(run_id or ""),
                    ),
                    workdir=(
                        Path(experience_root)
                        if experience_root is not None
                        else None
                    ),
                    metadata={
                        "log_path": self._log_path(
                            str(run_id or "run"),
                            "skill-level-classification",
                        )
                    },
                )
            )
        except Exception:
            _LOG.exception("existing Skill level classification failed")
            return []
        return self._parse_skill_classifications(result.text)

    @staticmethod
    def _parse_skill_classifications(text: str) -> list[dict]:
        candidates = [
            match.group("body").strip()
            for match in _JSON_FENCED.finditer(text or "")
        ]
        stripped = str(text or "").strip()
        candidates.append(stripped)
        for candidate in candidates:
            if not candidate:
                continue
            start = candidate.find("[")
            end = candidate.rfind("]")
            if start < 0 or end < start:
                continue
            try:
                value = json.loads(candidate[start : end + 1])
            except json.JSONDecodeError:
                continue
            if isinstance(value, list):
                return [item for item in value if isinstance(item, dict)]
        _LOG.warning("existing Skill classifier returned invalid JSON")
        return []

    def distill_plans(
        self,
        success_ids,
        *,
        existing_plans="",
        strategy_path=None,
        experience_root=None,
        run_id=None,
        **_kwargs,
    ):
        ids = list(success_ids or [])
        if not ids:
            return []
        with tempfile.TemporaryDirectory(prefix="openearth-sdk-planning-prompt-") as tmp:
            scratch = Path(tmp)
            out_dir = scratch / "out"
            return self._run_file_pass(
                instructions=prompts.planning_strategy(strategy_path),
                user_input=prompts.planning_user(
                    ids,
                    experience_root=experience_root,
                    out_dir=out_dir,
                    existing_plans=existing_plans,
                    run_id=str(run_id or ""),
                ),
                lane="planning",
                run_id=str(run_id or "run"),
                scratch=scratch,
                output=out_dir,
            )

    def reflect_functionals(
        self,
        fail_ids,
        *,
        planning_bank,
        plan_source,
        existing_functionals="",
        strategy_path=None,
        experience_root=None,
        run_id=None,
        **_kwargs,
    ):
        rows = list(fail_ids or [])
        if not rows:
            return []
        trajectory_id, signal = rows[0]
        with tempfile.TemporaryDirectory(prefix="openearth-sdk-functional-prompt-") as tmp:
            scratch = Path(tmp)
            out_dir = scratch / "out"
            return self._run_file_pass(
                instructions=prompts.functional_strategy(strategy_path),
                user_input=prompts.functional_user(
                    trajectory_id,
                    signal,
                    experience_root=experience_root,
                    out_dir=out_dir,
                    planning_bank=planning_bank,
                    plan_source=plan_source,
                    existing_functionals=existing_functionals,
                    run_id=str(run_id or ""),
                ),
                lane=f"functional-{slug(trajectory_id)}",
                run_id=str(run_id or "run"),
                scratch=scratch,
                output=out_dir,
            )

    def make_transient_plan(
        self,
        trajectory_id,
        *,
        signal="",
        experience_root=None,
        run_id=None,
        **_kwargs,
    ) -> str:
        try:
            result = self.backend.run(
                AgentRequest(
                    instructions=(
                        "Generate a transient diagnostic plan. Never write or "
                        "propose a runtime Skill."
                    ),
                    user_input=prompts.transient_user(
                        trajectory_id,
                        signal,
                        experience_root=experience_root,
                    ),
                    metadata={
                        "log_path": self._log_path(
                            str(run_id or "run"),
                            f"transient-{slug(trajectory_id)}",
                        )
                    },
                )
            )
        except Exception:
            _LOG.exception("transient Planning generation failed")
            return ""
        return str(result.text or "").strip()[:8000]

    def curate_functionals(
        self,
        candidates,
        *,
        existing_functionals="",
        strategy_path=None,
        experience_root=None,
        run_id=None,
        **_kwargs,
    ):
        with tempfile.TemporaryDirectory(prefix="openearth-sdk-curation-") as temporary:
            scratch = Path(temporary)
            candidates_dir = scratch / "candidates"
            output = scratch / "out"
            candidates_dir.mkdir()
            output.mkdir()
            for index, candidate in enumerate(candidates or []):
                fields = {
                    key: candidate[key]
                    for key in (
                        "candidate_id",
                        "name",
                        "description",
                        "kind",
                        "level",
                        "source_type",
                        "target_subgoal",
                        "planning_context",
                        "plan_source",
                        "source_steps",
                        "verified",
                        "source_trajs",
                        "reasoning",
                    )
                    if key in candidate
                }
                path = candidates_dir / (
                    f"{index:03d}-{slug(candidate.get('name', 'candidate'))}.md"
                )
                path.write_text(
                    serialize(fields, candidate.get("body", "")),
                    encoding="utf-8",
                )
            try:
                result = self.backend.run(
                    AgentRequest(
                        instructions=prompts.curation_strategy(strategy_path),
                        user_input=prompts.curation_user(
                            candidates_dir=candidates_dir,
                            out_dir=output,
                            existing_functionals=existing_functionals,
                            experience_root=experience_root,
                            run_id=str(run_id or ""),
                        ),
                        workdir=scratch,
                        output_dir=output,
                        metadata={
                            "log_path": self._log_path(
                                str(run_id or "run"),
                                "functional-curation",
                            )
                        },
                    )
                )
            except Exception:
                _LOG.exception("Functional curation failed")
                return None
            marker = output / "curation_complete.txt"
            if not marker.is_file() and "CURATION_COMPLETE" not in (result.text or ""):
                _LOG.warning(
                    "functional curator did not complete; preserving original candidates"
                )
                return None
            files = sorted(output.glob("*.md"))
            if files:
                return self._read_skill_files(files)
            return self._read_skill_texts(
                _response_documents(result.text),
                lane="curation",
            )

    @classmethod
    def _read_skill_files(cls, paths: list[Path]) -> list[dict]:
        texts = []
        for path in paths:
            try:
                texts.append(path.read_text(encoding="utf-8"))
            except OSError:
                continue
        return cls._read_skill_texts(texts, lane="files")

    @staticmethod
    def _read_skill_texts(texts: list[str], *, lane: str) -> list[dict]:
        output = []
        for index, text in enumerate(texts):
            canonical = text
            try:
                frontmatter, body = parse_strict(text)
            except FrontmatterError as exc:
                try:
                    repaired = _repair_plain_reasoning(text)
                except FrontmatterError:
                    repaired = None
                if repaired is None:
                    _LOG.warning(
                        "discarding invalid %s proposal %d: %s",
                        lane,
                        index,
                        exc,
                    )
                    continue
                frontmatter, body, canonical = repaired

            name = slug(str(frontmatter.get("name") or f"candidate-{index}"))
            description = " ".join(
                str(frontmatter.get("description") or "").split()
            ).strip()[:300]
            if not description or not body.strip():
                continue

            raw_sources = frontmatter.get("source_trajs", [])
            sources_valid = (
                isinstance(raw_sources, list)
                and bool(raw_sources)
                and all(
                    isinstance(source, str) and source.strip()
                    for source in raw_sources
                )
            )
            sources = (
                [source.strip() for source in raw_sources] if sources_valid else []
            )
            raw_steps = frontmatter.get("source_steps", [])
            if isinstance(raw_steps, int):
                raw_steps = [raw_steps]
            steps_valid = (
                isinstance(raw_steps, list)
                and bool(raw_steps)
                and all(
                    isinstance(step, int)
                    and not isinstance(step, bool)
                    and step >= 0
                    for step in raw_steps
                )
            )
            item = {
                "name": name,
                "description": description,
                "body": body.strip(),
                "content": canonical,
                "source_trajs": sources,
                "reasoning": " ".join(
                    str(frontmatter.get("reasoning") or "").split()
                )[:1000],
                "_source_trajs_valid": sources_valid,
            }
            for key in (
                "candidate_id",
                "kind",
                "level",
                "target_subgoal",
                "planning_context",
                "plan_source",
                "verified",
                "source_type",
                "status",
                "scope",
                "promotion_target",
                "applicable_plans",
                "promotion_exceptions",
                "promoted_from",
                "curated_from",
            ):
                if key in frontmatter:
                    item[key] = frontmatter[key]
            if isinstance(item.get("planning_context"), str):
                item["planning_context"] = [item["planning_context"]]
            if isinstance(item.get("curated_from"), str):
                item["curated_from"] = [item["curated_from"]]
            if "source_steps" in frontmatter:
                item["source_steps"] = list(raw_steps) if steps_valid else []
                item["_source_steps_valid"] = steps_valid
            output.append(item)
        return output
