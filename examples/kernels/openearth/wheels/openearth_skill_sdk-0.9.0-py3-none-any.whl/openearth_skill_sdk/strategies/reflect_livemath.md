---
name: reflect-livemath
description: Distill reusable mathematical problem-solving and answer-verification Skills.
---

# LiveMath reflection

Do not memorize task IDs, exact questions, option order, theorem text, or answer labels. Extract
reusable mathematical decomposition, invariant selection, branch handling, and independent
verification procedures.

Planning Skills should capture successful solve→check→label workflows. Functional Skills should
repair a localized reasoning, computation, theorem-selection, or final-label error and include an
inference-time verification step.
