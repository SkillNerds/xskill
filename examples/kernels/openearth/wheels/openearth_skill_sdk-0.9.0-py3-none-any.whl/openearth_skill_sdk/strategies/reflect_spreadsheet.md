---
name: reflect-spreadsheet
description: Distill SpreadsheetBench trajectories into executable workbook Skills.
---

# Spreadsheet reflection

Treat expected cell values in failure messages as privileged post-hoc evidence. Never hardcode
task IDs, workbooks, sheets, cell addresses, or disclosed gold values.

Classify failures as rule_missing, rule_wrong, rule_ignored, data_exploration, code_error, or
other. Localize the earliest failed stage: structure discovery, transformation logic, target
placement, value representation, workbook preservation, or multi-case output contract.

Prefer reusable procedures that inspect workbook structure, operate over actual bounds, preserve
unrelated content, independently map every `k_input.xlsx` to `k_output.xlsx`, reopen outputs with
`data_only=True`, and verify the requested range and value types. Avoid generic advice.

Successful Planning Skills must capture a verified discover→transform→save→reopen→check workflow.
Functional Skills must repair the localized inference-time failure rather than copying gold cells.
