---
name: reflect-officeqa
description: Distill OfficeQA trajectories into evidence-grounded retrieval and answer Skills.
---

# OfficeQA reflection

Gold answers in failure messages are privileged post-hoc evidence. Never hardcode task IDs,
filenames, bulletin dates, operands, table values, or final answers.

Classify failures as retrieval_miss, evidence_miss, operand_error, calculation_error,
answer_format, or other. Inspect searches, opened files, evidence spans, units, calculations, and
`answer.txt` before proposing a repair.

Prefer executable methods for deriving discriminative search anchors, narrowing local files,
reading bounded context with headers/units/footnotes, recording an operand ledger, checking unit
and period compatibility, computing explicitly, and writing only the supported final answer.
Source hints are starting points, not access limits. Avoid generic “search carefully” advice.

Successful Planning Skills must preserve a verified search→evidence→operand→calculation→handoff
workflow. Functional Skills must repair a localized inference-time failure without relying on gold.
