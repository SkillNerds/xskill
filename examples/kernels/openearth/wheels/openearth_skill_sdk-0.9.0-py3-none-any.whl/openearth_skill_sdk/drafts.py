"""Deterministic Skill draft rebasing for delayed provider publication."""
from __future__ import annotations

from .contracts import ExistingSkillInput, SkillDraft
from .frontmatter import parse_strict, serialize
from .workspace import OPTIMIZER_FIELDS


_PRIVATE_FIELDS = (
    "source_trajs",
    "reasoning",
    "curated_from",
    "candidate_id",
    "gate",
)


def rebase_skill_draft(
    draft: SkillDraft,
    current: ExistingSkillInput,
) -> SkillDraft:
    """Apply a delayed OpenEarth draft to the provider's latest main bundle.

    Provider-owned frontmatter and attachments come from ``current``. The
    delayed draft supplies the newer OpenEarth description, optimizer fields,
    body, and evidence attribution.
    """
    current_frontmatter, _current_body = parse_strict(current.skill_md)
    draft_frontmatter, draft_body = parse_strict(draft.skill_md)
    current_name = str(current_frontmatter.get("name") or "").strip()
    draft_name = str(draft_frontmatter.get("name") or "").strip()
    if current.name != draft.name or current_name != draft.name:
        raise ValueError(
            "cannot rebase Skill draft onto a different main Skill: "
            f"draft={draft.name!r}, current={current.name!r}"
        )
    if draft_name != draft.name:
        raise ValueError(
            "queued Skill draft name does not match its SKILL.md: "
            f"draft={draft.name!r}, frontmatter={draft_name!r}"
        )
    description = draft_frontmatter.get("description")
    if not isinstance(description, str) or not description.strip():
        raise ValueError(f"queued Skill draft {draft.name!r} has no description")

    merged = dict(current_frontmatter)
    merged["name"] = draft.name
    merged["description"] = description
    for key in OPTIMIZER_FIELDS:
        if key in draft_frontmatter:
            merged[key] = draft_frontmatter[key]
    for key in _PRIVATE_FIELDS:
        merged.pop(key, None)
    return SkillDraft(
        name=draft.name,
        skill_md=serialize(merged, draft_body),
        files=dict(current.files),
        source_trajectory_ids=draft.source_trajectory_ids,
        action="update",
        base_version_token=current.version_token,
    )
