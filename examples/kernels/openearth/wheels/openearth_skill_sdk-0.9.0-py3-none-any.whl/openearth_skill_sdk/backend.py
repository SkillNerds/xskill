"""Minimal reflect-agent backends shipped with the Skill SDK."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional, Protocol


@dataclass(frozen=True)
class AgentRequest:
    instructions: str
    user_input: str
    workdir: Optional[Path] = None
    output_dir: Optional[Path] = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AgentResult:
    text: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


class AgentBackend(Protocol):
    def run(self, request: AgentRequest) -> AgentResult: ...


class CompletionAdapter:
    def __init__(self, client) -> None:
        self.client = client

    def run(self, request: AgentRequest) -> AgentResult:
        text = self.client.complete(
            request.instructions,
            request.user_input,
            workdir=str(request.workdir) if request.workdir else None,
            log_path=request.metadata.get("log_path"),
        )
        return AgentResult(text=str(text or ""))


def ensure_backend(value) -> AgentBackend:
    if hasattr(value, "run"):
        return value
    if hasattr(value, "complete"):
        return CompletionAdapter(value)
    raise TypeError("reflect backend must provide run() or complete()")


def _event_text(stdout: str) -> str:
    chunks: list[str] = []
    for line in stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        part = event.get("part") if isinstance(event, dict) else None
        if not isinstance(part, dict) or part.get("type") != "text":
            continue
        text = str(part.get("text") or "")
        if text:
            chunks.append(text)
    return "\n".join(chunks)


class OpenCodeBackend:
    """Tool-capable OpenEarth reflect agent implemented through OpenCode."""

    def __init__(
        self,
        model: str,
        *,
        binary: str = "opencode",
        timeout: float = 600,
    ) -> None:
        self.model = model
        self.binary = binary
        self.timeout = timeout

    def run(self, request: AgentRequest) -> AgentResult:
        prompt = f"{request.instructions}\n\n{request.user_input}"
        temporary_workdir = None
        if request.workdir is None:
            temporary_workdir = tempfile.TemporaryDirectory(prefix="openearth-sdk-agent-")
            workdir = Path(temporary_workdir.name)
        else:
            workdir = Path(request.workdir)
            workdir.mkdir(parents=True, exist_ok=True)

        data_root = Path(tempfile.mkdtemp(prefix="openearth-sdk-opencode-"))
        opencode_data = data_root / "opencode"
        opencode_data.mkdir(parents=True, exist_ok=True)
        auth = Path.home() / ".local" / "share" / "opencode" / "auth.json"
        if auth.is_file():
            shutil.copy2(auth, opencode_data / "auth.json")
        environment = {
            **os.environ,
            "OPENCODE_PURE": "1",
            "XDG_DATA_HOME": str(data_root),
        }
        command = [
            self.binary,
            "run",
            "--pure",
            "--dangerously-skip-permissions",
            "--dir",
            str(workdir),
            "--model",
            self.model,
            "--format",
            "json",
        ]
        try:
            completed = subprocess.run(
                command,
                input=prompt,
                capture_output=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout,
                cwd=workdir,
                env=environment,
            )
            log_path = request.metadata.get("log_path")
            if log_path:
                target = Path(str(log_path))
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(
                    completed.stdout
                    + ("\n# stderr\n" + completed.stderr if completed.stderr else ""),
                    encoding="utf-8",
                )
            if completed.returncode:
                raise RuntimeError(
                    f"opencode reflect failed with exit {completed.returncode}: "
                    f"{completed.stderr[-2000:]}"
                )
            return AgentResult(
                text=_event_text(completed.stdout),
                metadata={"backend": "opencode", "model": self.model},
            )
        finally:
            shutil.rmtree(data_root, ignore_errors=True)
            if temporary_workdir is not None:
                temporary_workdir.cleanup()
