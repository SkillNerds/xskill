"""Target-agent runtime and layered Skill pre-routing for dataset evaluation."""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Iterable, Mapping, Optional

from .analyst import slug
from .contracts import ExistingSkillInput, TargetRun
from .frontmatter import parse_strict
from .workspace import _safe_relative


def _terms(text: str) -> set[str]:
    lowered = (text or "").lower()
    return set(re.findall(r"[a-z0-9]+", lowered)) | set(
        re.findall(r"[\u3400-\u9fff]", lowered)
    )


def _skill_records(
    skills: Iterable[ExistingSkillInput],
    skill_levels: Optional[Mapping[str, str]] = None,
) -> list[dict]:
    result = []
    for skill in skills:
        frontmatter, body = parse_strict(skill.skill_md)
        metadata = (
            frontmatter.get("metadata")
            if isinstance(frontmatter.get("metadata"), dict)
            else {}
        )
        level = str(
            (skill_levels or {}).get(skill.name)
            or frontmatter.get("level")
            or metadata.get("level")
            or "unclassified"
        ).strip().lower()
        result.append({
            "name": skill.name,
            "level": level,
            "description": str(frontmatter.get("description") or ""),
            "body": body,
            "bundle": skill,
        })
    return result


def _rank(records: list[dict], query: str, limit: int) -> list[dict]:
    query_terms = _terms(query)
    scored = []
    for record in records:
        content = (
            f"{record['name']} {record['description']} {record['body']}"
        )
        overlap = len(query_terms & _terms(content))
        scored.append((overlap, record["name"], record))
    scored.sort(key=lambda row: (-row[0], row[1]))
    return [row[2] for row in scored[: max(0, limit)]]


def route_layered_skills(
    task: dict,
    skills: Iterable[ExistingSkillInput],
    *,
    planning_k: int = 2,
    functional_k: int = 2,
    query: Optional[str] = None,
    skill_levels: Optional[Mapping[str, str]] = None,
) -> list[ExistingSkillInput]:
    """Select Planning first, then Functional using task + Planning context."""
    records = _skill_records(skills, skill_levels)
    task_query = query if query is not None else str(
        task.get("question") or task.get("instruction") or ""
    )
    planning = _rank(
        [row for row in records if row["level"] == "planning"],
        task_query,
        planning_k,
    )
    planning_context = "\n".join(row["body"] for row in planning)
    functional = _rank(
        [row for row in records if row["level"] == "functional"],
        f"{task_query}\n{planning_context}",
        functional_k,
    )
    return [row["bundle"] for row in planning + functional]


def _event_text(stdout: str) -> str:
    chunks = []
    for line in stdout.splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        part = event.get("part") if isinstance(event, dict) else None
        if not isinstance(part, dict):
            continue
        if part.get("type") in ("text", "reasoning"):
            text = str(part.get("text") or "")
            if text:
                chunks.append(text)
    return "\n".join(chunks)


class OpenCodeTargetAgent:
    """Run the actual target model with only progressively routed Skills installed."""

    def __init__(
        self,
        model: str,
        *,
        binary: str = "opencode",
        timeout: float = 900,
        planning_route_k: int = 2,
        functional_route_k: int = 2,
        environment=None,
        skill_levels: Optional[Mapping[str, str]] = None,
        workspace: Optional[Path] = None,
    ) -> None:
        if not model:
            raise ValueError("run.model is required for the target agent")
        self.model = model
        self.binary = binary
        self.timeout = timeout
        self.planning_route_k = planning_route_k
        self.functional_route_k = functional_route_k
        self.skill_levels = dict(skill_levels or {})
        self.workspace = Path(workspace).resolve() if workspace else None
        if environment is None:
            raise ValueError("target agent requires a dataset environment")
        self.environment = environment

    def run(
        self,
        task: dict,
        skills: Iterable[ExistingSkillInput],
        *,
        run_id: str,
        phase: str,
    ) -> TargetRun:
        selected = route_layered_skills(
            task,
            skills,
            planning_k=self.planning_route_k,
            functional_k=self.functional_route_k,
            query=self.environment.query(task),
            skill_levels=self.skill_levels,
        )
        selected_names = tuple(skill.name for skill in selected)
        workdir, prompt = self.environment.prepare(task)
        data_parent = None
        if self.workspace is not None:
            data_parent = self.workspace / "openearth-benchmark-runs"
            data_parent.mkdir(parents=True, exist_ok=True)
        data_root = Path(tempfile.mkdtemp(
            prefix="openearth-skill-opencode-",
            dir=data_parent,
        ))
        try:
            skills_root = workdir / ".opencode" / "skills"
            for skill in selected:
                target = skills_root / f"openearth-{slug(skill.name)}"
                target.mkdir(parents=True, exist_ok=True)
                (target / "SKILL.md").write_text(
                    skill.skill_md,
                    encoding="utf-8",
                )
                for relative, content in skill.files.items():
                    safe = _safe_relative(relative)
                    path = target.joinpath(*safe.parts)
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(content, encoding="utf-8")

            opencode_data = data_root / "opencode"
            opencode_data.mkdir(parents=True)
            auth = (
                Path.home()
                / ".local"
                / "share"
                / "opencode"
                / "auth.json"
            )
            if auth.is_file():
                shutil.copy2(auth, opencode_data / "auth.json")
            environment = {
                **os.environ,
                "OPENCODE_PURE": "1",
                "XDG_DATA_HOME": str(data_root),
            }
            completed = subprocess.run(
                [
                    self.binary,
                    "run",
                    "--pure",
                    "--dangerously-skip-permissions",
                    "--dir",
                    str(workdir),
                    "--model",
                    self.model,
                    "--format",
                    "json",
                ],
                input=prompt,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=self.timeout,
                cwd=workdir,
                env=environment,
            )
            transcript = _event_text(completed.stdout)
            cost = float(
                len(
                    [
                        line
                        for line in completed.stdout.splitlines()
                        if line.strip()
                    ]
                )
            )
            return self.environment.score(
                task,
                workdir,
                transcript=transcript,
                selected_skills=selected_names,
                cost=cost,
                process_error=(
                    completed.stderr[-2000:]
                    if completed.returncode
                    else ""
                ),
            )
        except subprocess.TimeoutExpired as exc:
            return self.environment.score(
                task,
                workdir,
                transcript=str(exc.stdout or ""),
                selected_skills=selected_names,
                cost=0.0,
                process_error=(
                    f"target agent timed out after {self.timeout}s"
                ),
            )
        finally:
            shutil.rmtree(data_root, ignore_errors=True)
            self.environment.cleanup(workdir)
