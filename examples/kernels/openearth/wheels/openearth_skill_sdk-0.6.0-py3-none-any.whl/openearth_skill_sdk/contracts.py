"""Provider-neutral public contracts for trajectory-to-Skill distillation."""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal, Mapping, Optional


class TrajectoryLabel(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    DEFERRED = "deferred"


@dataclass(frozen=True)
class ScoredAtomInput:
    """One provider-neutral Atom used as OpenEarth training evidence."""

    atom_id: str
    evidence_id: str
    parent_trajectory_id: str
    content: str
    ux_score: Optional[int]
    intent: str = ""
    summary: str = ""
    used_skills: tuple[str, ...] = ()
    score_source: Literal["xskill", "oracle"] = "xskill"
    metadata: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class ExistingSkillInput:
    """Complete read-only snapshot of one provider-owned main Skill bundle."""

    name: str
    skill_md: str
    files: Mapping[str, str] = field(default_factory=dict)
    version_token: Optional[str] = None


@dataclass(frozen=True)
class SkillDraft:
    """Complete curated candidate returned to the provider publication layer."""

    name: str
    skill_md: str
    files: Mapping[str, str]
    source_trajectory_ids: tuple[str, ...]
    action: Literal["create", "update"]
    base_version_token: Optional[str] = None


@dataclass(frozen=True)
class DistillationResult:
    """One bounded trajectory-training run before provider publication."""

    run_id: str
    candidate_dir: Optional[str]
    drafts: tuple[SkillDraft, ...] = ()
    processed_trajectory_ids: tuple[str, ...] = ()
    processed_atom_ids: tuple[str, ...] = ()
    metrics: Mapping[str, object] = field(default_factory=dict)
    notes: str = ""

    @property
    def branch(self) -> Optional[str]:
        """Compatibility name used by the initial OpenEarth integration."""
        return self.candidate_dir


# Public name for the unified trajectory-only training result. Keep the
# original class name internally so existing serialized/debug output remains
# recognizable while the SDK surface moves to one training vocabulary.
TrainingResult = DistillationResult
