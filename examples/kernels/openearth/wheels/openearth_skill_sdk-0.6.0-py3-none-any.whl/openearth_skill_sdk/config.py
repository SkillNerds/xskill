"""Small SDK-only configuration loader."""
from __future__ import annotations

from pathlib import Path
from typing import Union

import yaml


DEFAULTS = {
    "analyst": {
        "model": "",
        "base_url": "",
        "api_key_env": "OPENEARTH_ANALYST_KEY",
        "timeout": 600,
    },
    "reflect": {
        "model": "",
        "base_url": "opencode",
        "api_key_env": "OPENEARTH_ANALYST_KEY",
        "temperature": 0.2,
        "max_tokens": 4096,
        "timeout": 600,
        "tools": True,
        "strategy": "",
    },
}


def _merge(base: dict, override: dict) -> dict:
    result = {
        key: dict(value) if isinstance(value, dict) else value
        for key, value in base.items()
    }
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            result[key] = _merge(base[key], value)
        else:
            result[key] = value
    return result


def load_config(path: Union[str, Path]) -> dict:
    config_path = Path(path).expanduser()
    raw = (
        yaml.safe_load(config_path.read_text(encoding="utf-8"))
        if config_path.is_file()
        else {}
    )
    if raw is None:
        raw = {}
    if not isinstance(raw, dict):
        raise ValueError(f"config must be a YAML mapping: {config_path}")
    return _merge(DEFAULTS, raw)


def role_config(config: dict, role: str = "reflect") -> dict:
    settings = dict(config.get("analyst") or {})
    for key, value in (config.get(role) or {}).items():
        if value not in ("", None):
            settings[key] = value
    return settings
