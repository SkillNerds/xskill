"""Validation helpers for generated Skill bundle attachments."""
from __future__ import annotations

from pathlib import PurePosixPath
from typing import Mapping


MAX_BUNDLE_BYTES = 2 * 1024 * 1024
_GENERATED_ROOTS = {"references", "scripts"}


def safe_attachment_path(value: str) -> PurePosixPath:
    """Return a normalized, provider-safe generated attachment path."""
    path = PurePosixPath(value)
    if (
        not value
        or "\\" in value
        or path.is_absolute()
        or path.as_posix() != value
        or ".." in path.parts
        or len(path.parts) < 2
        or path.parts[0] not in _GENERATED_ROOTS
        or any(part.startswith(".") for part in path.parts)
        or path.name == "SKILL.md"
    ):
        raise ValueError(f"unsafe generated Skill attachment path: {value!r}")
    return path


def validate_generated_files(
    files: object,
    *,
    body: str,
    skill_md_bytes: int = 0,
) -> dict[str, str]:
    """Validate an attachment delta emitted by the reflect agent.

    Generated files are UTF-8 text below ``references/`` or ``scripts/`` and
    must be linked by their exact relative path from SKILL.md. This keeps the
    bundle discoverable and prevents silently publishing orphaned artifacts.
    """
    if files is None:
        return {}
    if not isinstance(files, Mapping):
        raise ValueError("generated Skill files must be a mapping")
    normalized: dict[str, str] = {}
    total = skill_md_bytes
    for raw_path, content in files.items():
        if not isinstance(raw_path, str):
            raise ValueError("generated Skill attachment paths must be text")
        relative = safe_attachment_path(raw_path).as_posix()
        if not isinstance(content, str):
            raise ValueError(
                f"generated Skill attachment must be UTF-8 text: {raw_path!r}"
            )
        if relative not in body:
            raise ValueError(
                f"generated Skill attachment is not referenced by SKILL.md: "
                f"{relative!r}"
            )
        total += len(content.encode("utf-8"))
        normalized[relative] = content
    if total > MAX_BUNDLE_BYTES:
        raise ValueError(f"generated Skill bundle exceeds {MAX_BUNDLE_BYTES} bytes")
    return normalized
