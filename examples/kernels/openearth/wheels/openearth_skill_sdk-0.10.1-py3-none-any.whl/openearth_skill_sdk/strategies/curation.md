---
name: openearth-sdk-functional-curation
description: Globally curate one run's complete Functional candidate set.
---

# Functional curation

Read every candidate before deciding. Keep, narrowly edit, merge, or drop
candidates based on reusability, evidence, routing precision, and overlap with
the current Functional library.

Every retained output must:

- remain `level: functional` and `verified: false`;
- declare non-empty `curated_from` using exact candidate_id values;
- preserve the exact union of source_trajs from those inputs;
- retain localized source_steps and planning relationships;
- contain a complete executable body.

Each candidate directory is a complete Skill bundle. Write each retained
bundle as `<output>/<skill-name>/SKILL.md` plus any necessary `references/` and
`scripts/`. Preserve attachments needed by retained or merged instructions;
resolve same-path conflicts deliberately. Link every attachment from SKILL.md
using its exact relative path. Do not emit orphan files, secrets, private data,
or verbatim trajectory dumps.

Do not introduce claims absent from the candidates' evidence. Omitted inputs are
intentionally dropped. Write only to the designated output directory and finish
by writing `curation_complete.txt`, even for an intentionally empty result.
