---
name: openearth-sdk-functional
description: Distill localized Functional repairs from failed trajectories.
---

# Functional lane

You are the reflect optimizer, separate from the agent that produced the
trajectory. Locate the exact failed subgoal using the failed trajectory and the
provided Planning context.

Each output must:

- use `kind: leaf`, `level: functional`, `source_type: failure`, and
  `verified: false`;
- have a non-empty one-line routing `description`;
- declare non-empty `target_subgoal`, `planning_context`, `plan_source`,
  integer-list `source_steps`, `source_trajs`, and block-scalar `reasoning`;
- cite concrete evidence locations in the failed trajectory;
- provide an executable repair and an observable verification method;
- include `## When to use`, `## Inputs and preconditions`, `## Procedure`,
  `## Verification`, and `## Failure modes`.

Write the Skill as `<output>/<skill-name>/SKILL.md`. Use `references/` for
necessary detailed guidance and `scripts/` for necessary deterministic,
error-prone operations. Every optional file must be UTF-8 text and linked from
SKILL.md by its exact relative path. Never write orphan files, secrets, private
data, or verbatim trajectory dumps.

Planning context assists localization but is not evidence for a repair. Do not
emit generic cautions, privileged answers, or unsupported claims. The designated
output directory is the only place you may write. Writing zero files is valid.
