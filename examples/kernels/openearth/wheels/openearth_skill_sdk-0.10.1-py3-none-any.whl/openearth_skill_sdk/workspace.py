"""Persistent Skill-only workspace for the standalone SDK."""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path, PurePosixPath
from typing import Iterable, Union

from .analyst import slug
from .contracts import ExistingSkillInput
from .frontmatter import parse_strict, serialize


OPTIMIZER_FIELDS = (
    "topic",
    "related",
    "kind",
    "level",
    "target_subgoal",
    "planning_context",
    "plan_source",
    "source_steps",
    "verified",
    "source_type",
    "status",
    "scope",
    "promotion_target",
    "applicable_plans",
    "promotion_exceptions",
    "promoted_from",
)


def _safe_relative(value: str) -> PurePosixPath:
    path = PurePosixPath(value)
    if (
        not value
        or path.is_absolute()
        or ".." in path.parts
        or path.parts[0].startswith(".")
    ):
        raise ValueError(f"unsafe Skill attachment path: {value!r}")
    return path


def _atomic_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


class DistillationWorkspace:
    """Own only trajectory evidence, Skill snapshots, candidates, and state."""

    def __init__(self, workspace: Union[str, Path]) -> None:
        self.root = Path(workspace).expanduser().resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.experience_root = self.root / "openearth-experience"
        self.trajectory_root = self.experience_root / "trajectories"
        self.main_skills_root = self.experience_root / "skills" / "main"
        self.candidates_root = self.experience_root / "skills" / "candidates"
        self.state_path = self.root / "openearth-distillation-state.json"
        self.skill_classifications_path = (
            self.root / "openearth-skill-level-classifications.json"
        )
        self.trajectory_root.mkdir(parents=True, exist_ok=True)
        self.main_skills_root.mkdir(parents=True, exist_ok=True)
        self.candidates_root.mkdir(parents=True, exist_ok=True)

    def load_state(self) -> dict:
        if not self.state_path.is_file():
            return {"version": 3, "trajectories": {}}
        value = json.loads(self.state_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError(f"invalid distillation state: {self.state_path}")
        trajectories = value.get("trajectories", value.get("atoms", {}))
        if not isinstance(trajectories, dict):
            raise ValueError(f"invalid distillation state: {self.state_path}")
        return {"version": 3, "trajectories": trajectories}

    def save_state(self, state: dict) -> None:
        _atomic_text(
            self.state_path,
            json.dumps(state, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        )

    def load_skill_classifications(self) -> dict:
        if not self.skill_classifications_path.is_file():
            return {"schema": 1, "skills": {}}
        value = json.loads(
            self.skill_classifications_path.read_text(encoding="utf-8")
        )
        if (
            not isinstance(value, dict)
            or value.get("schema") != 1
            or not isinstance(value.get("skills"), dict)
        ):
            raise ValueError(
                "invalid OpenEarth Skill classification cache: "
                f"{self.skill_classifications_path}"
            )
        return value

    def save_skill_classifications(self, value: dict) -> None:
        _atomic_text(
            self.skill_classifications_path,
            json.dumps(
                value,
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
            + "\n",
        )

    def sync_main_skills(
        self,
        skills: Iterable[ExistingSkillInput],
    ) -> dict[str, ExistingSkillInput]:
        snapshots: dict[str, ExistingSkillInput] = {}
        parsed: dict[str, tuple[dict, str]] = {}
        for snapshot in skills:
            frontmatter, body = parse_strict(snapshot.skill_md)
            name = str(frontmatter.get("name") or snapshot.name).strip()
            description = frontmatter.get("description")
            if name != snapshot.name or not name:
                raise ValueError(
                    "existing Skill name mismatch: "
                    f"input={snapshot.name!r}, frontmatter={name!r}"
                )
            if not isinstance(description, str) or not description.strip():
                raise ValueError(f"existing Skill {name!r} has no description")
            for relative, content in snapshot.files.items():
                _safe_relative(relative)
                if not isinstance(content, str):
                    raise ValueError(
                        f"existing Skill {name!r} files must contain text"
                    )
            snapshots[name] = snapshot
            parsed[name] = (frontmatter, body)

        replacement = self.experience_root / "skills" / ".main-next"
        if replacement.exists():
            shutil.rmtree(replacement)
        replacement.mkdir(parents=True)
        for name in sorted(snapshots):
            snapshot = snapshots[name]
            target = replacement / slug(name)
            target.mkdir()
            _atomic_text(target / "SKILL.md", snapshot.skill_md)
            for relative, content in snapshot.files.items():
                path = _safe_relative(relative)
                if path.as_posix() == "SKILL.md":
                    raise ValueError("files must not contain SKILL.md")
                _atomic_text(target.joinpath(*path.parts), content)
            frontmatter, body = parsed[name]
            metadata = {
                key: frontmatter[key]
                for key in OPTIMIZER_FIELDS
                if key in frontmatter
            }
            _atomic_text(
                target / ".openearth.json",
                json.dumps(
                    {
                        "name": name,
                        "description": frontmatter["description"],
                        "metadata": metadata,
                        "body_sha256": hashlib.sha256(
                            body.encode("utf-8")
                        ).hexdigest(),
                    },
                    ensure_ascii=False,
                    indent=2,
                    sort_keys=True,
                )
                + "\n",
            )

        previous = self.experience_root / "skills" / ".main-previous"
        if previous.exists():
            shutil.rmtree(previous)
        if self.main_skills_root.exists():
            self.main_skills_root.replace(previous)
        replacement.replace(self.main_skills_root)
        if previous.exists():
            shutil.rmtree(previous)
        return snapshots

    def materialize_trajectory(
        self,
        *,
        internal_id: str,
        resource_id: str,
        trajectory_id: str,
        content: str,
        ux_score: int,
        label: str,
        intent: str,
        summary: str,
        used_skills: tuple[str, ...],
        metadata: dict,
    ) -> None:
        header = (
            f"# OpenEarth trajectory evidence\n\n"
            f"- internal_id: {internal_id}\n"
            f"- resource_id: {resource_id}\n"
            f"- trajectory_id: {trajectory_id}\n"
            f"- ux_score: {ux_score}\n"
            f"- label: {label}\n"
            f"- intent: {intent}\n"
            f"- summary: {summary}\n"
            f"- used_skills: {', '.join(used_skills)}\n\n"
            "## Transcript\n\n"
        )
        _atomic_text(self.trajectory_root / f"{internal_id}.md", header + content)
        _atomic_text(
            self.trajectory_root / f"{internal_id}.json",
            json.dumps(
                {
                    "internal_id": internal_id,
                    "resource_id": resource_id,
                    "trajectory_id": trajectory_id,
                    "ux_score": ux_score,
                    "label": label,
                    "intent": intent,
                    "summary": summary,
                    "used_skills": list(used_skills),
                    "metadata": metadata,
                },
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
                default=str,
            )
            + "\n",
        )

    def start_candidate_run(self, run_id: str) -> Path:
        target = self.candidates_root / slug(run_id)
        if target.exists():
            raise ValueError(f"distillation candidate run already exists: {target}")
        target.mkdir(parents=True)
        return target

    def save_transient_plan(
        self,
        run_dir: Path,
        *,
        internal_id: str,
        evidence_id: str,
        parent_trajectory_id: str,
        plan: str,
    ) -> str:
        """Persist non-publishable Planning context for audit and attribution."""
        target = run_dir / "transient-plans" / f"{slug(internal_id)}.md"
        content = (
            "# Transient pseudo plan\n\n"
            f"- evidence_id: {evidence_id}\n"
            f"- parent_trajectory_id: {parent_trajectory_id}\n"
            "- lifecycle: candidate-only; never published as a runtime Skill\n\n"
            "## Plan\n\n"
            f"{str(plan or '').strip() or '(no plan content returned)'}\n"
        )
        _atomic_text(target, content)
        return target.relative_to(self.experience_root).as_posix()

    def save_candidate(self, run_dir: Path, candidate: dict) -> None:
        fields = {
            key: candidate[key]
            for key in (
                "name",
                "description",
                "kind",
                "level",
                "target_subgoal",
                "planning_context",
                "plan_source",
                "source_steps",
                "verified",
                "source_type",
                "status",
                "scope",
                "promotion_target",
                "applicable_plans",
                "promotion_exceptions",
                "promoted_from",
                "source_trajs",
                "reasoning",
            )
            if key in candidate
        }
        target = run_dir / slug(candidate["name"])
        _atomic_text(
            target / "SKILL.md",
            serialize(fields, candidate["body"]),
        )
        for relative, content in candidate.get("files", {}).items():
            path = _safe_relative(relative)
            _atomic_text(target.joinpath(*path.parts), content)
