"""OpenEarth trajectory-only Skill training SDK."""
from importlib.metadata import PackageNotFoundError, version

from .contracts import (
    DistillationResult,
    ExistingSkillInput,
    ScoredAtomInput,
    SkillDraft,
    TrainingResult,
    TrajectoryLabel,
)
from .labels import label_for_ux_score
from .drafts import rebase_skill_draft
from .service import TrajectorySkillDistiller
from .xskill import record_oracle_score, train_skills

try:
    __version__ = version("openearth-skill-sdk")
except PackageNotFoundError:
    __version__ = "0.8.0"

__all__ = [
    "DistillationResult",
    "ExistingSkillInput",
    "ScoredAtomInput",
    "SkillDraft",
    "TrainingResult",
    "TrajectoryLabel",
    "TrajectorySkillDistiller",
    "label_for_ux_score",
    "rebase_skill_draft",
    "record_oracle_score",
    "train_skills",
    "__version__",
]
